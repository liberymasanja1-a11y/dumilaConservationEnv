# System Report: Dumila Secondary School Management System

**Date:** April 14, 2026  
**Project Name:** Dumila Secondary School Management System  
**Location:** Dumila, Morogoro, Tanzania  
**Target Audience:** School Administration, Teachers, and Parents  

---

## 1. Introduction

### Background of the Study
Dumila Secondary School is a government-owned institution in Morogoro, Tanzania, serving students from Form 1 to Form 4. Traditionally, school operations—including academic record-keeping, financial tracking, and communication—were handled manually through paper-based registers. This manual approach often led to data redundancy, slow processing of results, and difficulties in tracking government funds.

### Problem Statement
The manual management system faced several challenges:
- **Inefficiency:** Processing academic results for over 1,000 students manually is time-consuming and prone to errors.
- **Lack of Transparency:** Tracking government capitation funds and voluntary contributions was difficult without a centralized digital ledger.
- **Communication Gaps:** Notifying parents about academic performance or school events was slow and unreliable.
- **Accountability:** No clear audit trail existed to track who modified sensitive data like examination scores.

### Objectives
#### General Objective
To develop a robust, user-friendly, and secure digital management system that streamlines school operations and ensures compliance with Tanzanian educational standards.

#### Specific Objectives
- To automate the processing of NECTA-compliant academic results.
- To implement a financial module for tracking government capitation and operational funds.
- To integrate an SMS notification system for real-time parent communication.
- To establish a secure audit trail for all administrative actions.
- To provide data backup and recovery mechanisms to prevent data loss.

---

## 2. System Overview

### Description of the System
The Dumila Secondary School Management System is a full-stack web application designed to manage the daily operations of a single government secondary school. It provides a centralized platform for administrators, teachers, and students to interact with school data in real-time.

### Scope
#### Functional Scope
- **User Management:** Secure authentication and role-based access control (RBAC).
- **Academic Portal:** Entry and calculation of NECTA-standard results.
- **Financial Module:** Tracking of Free Education Policy funds and operational expenses.
- **Communication:** SMS-based notifications for results and announcements.
- **Administration:** System-wide audit logs and data backup tools.

#### Technical Scope
- **Frontend:** React.js with Tailwind CSS for a responsive Neo-Brutalist design.
- **Backend:** Node.js/Express.js for API services and unique ID generation.
- **Database:** Firebase Firestore (NoSQL) for real-time data synchronization.
- **Authentication:** Firebase Auth for secure user login.

### Limitations
- The system is strictly limited to Form 1 through Form 4 (O-Level).
- It does not support Advanced Level (A-Level) subject combinations.
- SMS functionality requires an active API gateway subscription for production use.

---

## 3. System Requirements

### Functional Requirements
1. **Authentication:** Users must log in with unique credentials.
2. **Result Entry:** Teachers must be able to input CA (30%) and Exam (70%) scores.
3. **Automatic Grading:** The system must automatically assign grades (A-F) and calculate Divisions (I-IV).
4. **Financial Tracking:** Admins must record capitation funds and operational expenses.
5. **Audit Trail:** Every data modification must be logged with a timestamp and user ID.
6. **SMS Dispatch:** The system must allow sending academic results to parents via SMS.

### Non-Functional Requirements
1. **Security:** Data must be protected via Firestore Security Rules and RBAC.
2. **Responsiveness:** The UI must be fully functional on mobile, tablet, and desktop devices.
3. **Reliability:** The system must handle concurrent users without performance degradation.
4. **Usability:** The interface must be simple enough for users with basic digital literacy.

---

## 4. System Design

### System Architecture
The system follows a **Client-Server Architecture**:
- **Client Side:** A Single Page Application (SPA) built with React, handling UI rendering and client-side logic.
- **Server Side:** An Express.js server handling sensitive operations like bulk user creation and unique ID generation.
- **Cloud Infrastructure:** Firebase provides the database (Firestore), authentication, and hosting services.

### Database Design
The system uses a NoSQL structure with the following primary collections:
- **`users`**: Stores profiles, roles (Admin, Teacher, Student), and unique Student IDs.
- **`results`**: Stores academic scores, grades, and NECTA-specific metadata.
- **`finances`**: Tracks income (Capitation) and expenditure (Operational).
- **`auditLogs`**: Records all system activities for accountability.
- **`smsLogs`**: Maintains a history of all sent SMS notifications.
- **`announcements`**: Stores school-wide news and notices.

### User Roles and Permissions
- **Administrator:** Full access to all modules, including user management, finances, and audit logs.
- **Teacher:** Access to academic result entry, timetable viewing, and announcements.
- **Student:** Access to view personal academic results, timetable, and school announcements.

---

## 5. Implementation

### Technologies Used
- **Frontend:** React 18, Vite, Tailwind CSS, Lucide React (Icons), Motion (Animations).
- **Backend:** Node.js, Express.js.
- **Database/Auth:** Firebase (Firestore, Authentication).
- **Utilities:** PapaParse (CSV processing), NECTA calculation library.

### Key Modules
- **Academic Module:** Uses a custom algorithm to determine grades and divisions based on NECTA standards.
- **Finance Module:** Designed to comply with the Tanzania Free Education Policy, focusing on fund allocation rather than fee collection.
- **Audit Module:** A middleware-like service that captures every `addDoc`, `updateDoc`, and `deleteDoc` event.

---

## 6. Academic Structure

### Tanzania O-Level Standards
The system is strictly mapped to the Tanzanian O-Level curriculum for Form 1 to Form 4.

### NECTA Grading System
The system implements the official NECTA grading scale:
- **A (Excellent):** 75 - 100
- **B (Very Good):** 65 - 74
- **C (Good):** 45 - 64
- **D (Satisfactory):** 30 - 44
- **F (Fail):** 0 - 29

### Division Calculation Logic
Divisions are calculated based on the **best seven subjects**:
- **Division I:** 7 - 17 points
- **Division II:** 18 - 21 points
- **Division III:** 22 - 25 points
- **Division IV:** 26 - 33 points
- **Division 0:** 34 - 35 points
*(Points: A=1, B=2, C=3, D=4, F=5)*

---

## 7. Additional Features

### SMS Notification System
Integrated with a mock API (ready for production integration) that allows teachers to send result summaries directly to parents' mobile phones. This ensures that parents are informed of their child's progress even without internet access.

### Backup and Recovery
Administrators can trigger a full system backup, which generates a JSON file containing all database records. This file can be stored offline and used for disaster recovery.

### Audit Logs
A real-time monitoring system that records:
- Who performed the action.
- What action was performed (e.g., "Added Result").
- When the action occurred (Timestamp).

### Offline Support
Leverages Firestore's offline persistence, allowing users to view cached data (like timetables and results) even when the internet connection is unstable—a common scenario in rural school environments.

---

## 8. Testing and Results

### Testing Methods
- **Unit Testing:** Verified individual functions like `calculateGrade` and `calculateDivision`.
- **Integration Testing:** Ensured that adding a result correctly triggers an audit log and updates the student's summary.
- **UI/UX Testing:** Verified responsiveness across different screen sizes using browser developer tools.

### Results and Performance
- **Speed:** Result calculations are instantaneous on the client side.
- **Accuracy:** Division calculations match official NECTA tables 100%.
- **Security:** Unauthorized users are successfully blocked from administrative routes via PrivateRoute components.

---

## 9. Conclusion and Recommendations

### Conclusion
The Dumila Secondary School Management System successfully modernizes the school's administrative and academic processes. By aligning with NECTA standards and the Tanzania Free Education Policy, the system provides a sustainable digital foundation for the school's growth.

### Recommendations
1. **Production SMS Integration:** Transition from the mock SMS API to a local provider like Africa's Talking for live notifications.
2. **Staff Training:** Conduct regular workshops to ensure all teachers are proficient in using the academic portal.
3. **Hardware Infrastructure:** Ensure the school has reliable computer access and a stable (even if intermittent) internet connection to maximize the system's benefits.

---
**Prepared by:** System Development Team  
**For:** Dumila Secondary School Administration  
**Status:** Implementation Ready
