import React, { useState, useEffect, useRef } from 'react';
import { apiFetch } from '../lib/api';
import { UserPlus, Trash2, Shield, Loader2, Upload, FileSpreadsheet, AlertCircle, Search, Filter, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import Papa from 'papaparse';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminUserManagement() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'teacher' | 'parent' | 'student'>('student');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newForm, setNewForm] = useState('Form 1');
  const [creating, setCreating] = useState(false);
  const [bulkLoading, setBulkLoading] = useState(false);
  const [bulkResult, setBulkResult] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (err) => {
      console.error(err);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      await apiFetch('/api/users', {
        method: 'POST',
        body: {
          username: newUsername,
          password: newPassword,
          role: newRole,
          displayName: newDisplayName,
          form: newRole === 'student' ? newForm : undefined
        } as any
      });

      setNewUsername('');
      setNewPassword('');
      setNewDisplayName('');
    } catch (error) {
      console.error("Error creating user:", error);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await apiFetch(`/api/users/${userId}`, { method: 'DELETE' });
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setBulkLoading(true);
    setBulkResult(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const response = await apiFetch('/api/users/bulk', {
            method: 'POST',
            body: results.data as any
          });
          setBulkResult(response);
        } catch (err) {
          console.error("Bulk upload error:", err);
          alert("Failed to upload users. Please check the file format.");
        } finally {
          setBulkLoading(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      },
      error: (err) => {
        console.error("CSV Parse error:", err);
        setBulkLoading(false);
        alert("Error parsing CSV file.");
      }
    });
  };

  const filteredUsers = users.filter(u => {
    const searchStr = `${u.displayName} ${u.username} ${u.role}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">User Management</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Control access and user roles</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)]">
            <h3 className="text-xl font-black mb-8 flex items-center gap-3 uppercase tracking-tight text-[#800000]">
              <div className="w-10 h-10 bg-[#fdfcf0] rounded-xl flex items-center justify-center border-2 border-[#800000]">
                <UserPlus className="w-5 h-5 text-[#800000]" />
              </div>
              Create New Account
            </h3>
            <form onSubmit={handleCreateUser} className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe"
                  value={newDisplayName}
                  onChange={(e) => setNewDisplayName(e.target.value)}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Username</label>
                <input
                  type="text"
                  placeholder="e.g. john.doe"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Password</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">System Role</label>
                <select
                  value={newRole}
                  onChange={(e: any) => setNewRole(e.target.value)}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                >
                  <option value="student">Student</option>
                  <option value="teacher">Teacher</option>
                  <option value="parent">Parent</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              {newRole === 'student' && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Form / Level</label>
                  <select
                    value={newForm}
                    onChange={(e) => setNewForm(e.target.value)}
                    className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  >
                    <option value="Form 1">Form 1</option>
                    <option value="Form 2">Form 2</option>
                    <option value="Form 3">Form 3</option>
                    <option value="Form 4">Form 4</option>
                  </select>
                </div>
              )}
              <div className="sm:col-span-2 flex justify-end mt-4">
                <button
                  type="submit"
                  disabled={creating}
                  className="px-10 py-4 bg-[#800000] text-white font-black rounded-2xl hover:bg-[#daa520] hover:text-[#800000] transition-all disabled:opacity-50 flex items-center justify-center gap-3 text-[10px] uppercase tracking-widest shadow-xl shadow-black/10 active:scale-95"
                >
                  {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                  Register User
                </button>
              </div>
            </form>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
                <input
                  type="text"
                  placeholder="Search users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-white border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                />
              </div>
              <button className="px-6 py-4 bg-white border-2 border-[#800000] rounded-2xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
                <Filter className="w-4 h-4" />
                <span>Filter</span>
              </button>
            </div>

            <div className="bg-white rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-[#fdfcf0] border-b-2 border-[#800000]">
                      <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">User</th>
                      <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">ID / Form</th>
                      <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Role</th>
                      <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Username</th>
                      <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y-2 divide-[#800000]/5">
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-[#fdfcf0]/50 transition-colors group">
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#800000] rounded-xl flex items-center justify-center text-white font-black text-xs shadow-lg group-hover:rotate-6 transition-transform">
                              {user.displayName?.[0] || user.username?.[0]?.toUpperCase()}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-black text-[#800000] text-sm">{user.displayName}</span>
                              <span className="text-[9px] font-bold text-[#800000]/30 uppercase tracking-widest">Active Member</span>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex flex-col">
                            <span className="text-xs font-black text-[#800000]">{user.studentId || 'N/A'}</span>
                            {user.form && <span className="text-[9px] font-bold text-[#daa520] uppercase tracking-widest">{user.form}</span>}
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border-2 ${
                            user.role === 'admin' ? 'bg-red-50 text-red-600 border-red-100' :
                            user.role === 'teacher' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                            user.role === 'parent' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                            'bg-green-50 text-green-600 border-green-100'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-xs font-bold text-[#800000]/40 tracking-tight">{user.username}</td>
                        <td className="px-8 py-5 text-right">
                          <button 
                            onClick={() => handleDeleteUser(user.id)}
                            className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-90"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-[#800000] p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] text-white">
            <h3 className="text-xl font-black mb-2 flex items-center gap-3 uppercase tracking-tight">
              <FileSpreadsheet className="w-5 h-5 text-[#DAA520]" />
              Bulk Import
            </h3>
            <p className="text-xs font-bold text-white/40 uppercase tracking-widest mb-8 leading-relaxed">
              Register multiple users at once using a CSV file.
            </p>
            
            <div className="space-y-6">
              <input
                type="file"
                accept=".csv"
                onChange={handleBulkUpload}
                ref={fileInputRef}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={bulkLoading}
                className="w-full flex items-center justify-center gap-3 px-6 py-5 bg-white text-[#800000] rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-[#DAA520] hover:text-[#800000] transition-all disabled:opacity-50 shadow-xl shadow-black/20"
              >
                {bulkLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                Select CSV File
              </button>
              
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <p className="text-[9px] font-bold text-white/40 uppercase tracking-[0.2em] mb-3">Required Headers</p>
                <div className="flex flex-wrap gap-2">
                  {['username', 'password', 'displayName', 'role', 'email'].map(h => (
                    <code key={h} className="px-2 py-1 bg-white/10 rounded-lg text-[10px] font-bold text-[#DAA520]">{h}</code>
                  ))}
                </div>
              </div>

              <a 
                href="data:text/csv;charset=utf-8,username,password,displayName,role,email%0Astudent1,pass123,Student One,student,student1@dumila.ac.tz%0Ateacher1,pass123,Teacher One,teacher,teacher1@dumila.ac.tz" 
                download="user_template.csv"
                className="flex items-center justify-center gap-2 text-[10px] font-black text-[#DAA520] hover:text-white transition-colors uppercase tracking-widest group"
              >
                Download Sample Template
                <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>

            <AnimatePresence>
              {bulkResult && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`mt-8 p-6 rounded-2xl border-2 ${bulkResult.errors.length > 0 ? 'bg-orange-500/10 border-orange-500/20 text-orange-200' : 'bg-green-500/10 border-green-500/20 text-green-200'}`}
                >
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest">Import Complete</p>
                      <div className="flex gap-4 mt-2">
                        <div className="flex flex-col">
                          <span className="text-xl font-black text-white">{bulkResult.created}</span>
                          <span className="text-[8px] font-bold uppercase tracking-widest opacity-40">Created</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xl font-black text-white">{bulkResult.skipped}</span>
                          <span className="text-[8px] font-bold uppercase tracking-widest opacity-40">Skipped</span>
                        </div>
                      </div>
                      {bulkResult.errors.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-white/10">
                          <p className="text-[8px] font-bold uppercase tracking-widest opacity-40 mb-2">Error Log</p>
                          <ul className="space-y-1">
                            {bulkResult.errors.slice(0, 3).map((err: string, i: number) => (
                              <li key={i} className="text-[9px] font-medium leading-tight">• {err}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
