import React, { useEffect, useState } from 'react';
import { Users, Search, GraduationCap, Filter, ArrowUpRight, Mail, Phone, Calendar } from 'lucide-react';
import { collection, onSnapshot, query, where, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';

export default function StudentsView() {
  const [students, setStudents] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'users'), where('role', '==', 'student'), orderBy('displayName', 'asc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setStudents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredStudents = students.filter(s => 
    s.displayName?.toLowerCase().includes(search.toLowerCase()) ||
    s.username?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">Student Directory</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Academic community of Dumila Secondary</p>
        </div>
      </header>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
          <input
            type="text"
            placeholder="Search by name or username..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
          />
        </div>
        <button className="px-6 py-4 bg-white border-2 border-[#800000] rounded-2xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
          <Filter className="w-4 h-4" />
          <span>Filter</span>
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-48 bg-white rounded-3xl border-2 border-[#1a1a1a]/5 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStudents.map((student, index) => (
            <motion.div
              key={student.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] hover:shadow-[12px_12px_0px_0px_rgba(128,0,0,1)] transition-all group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowUpRight className="w-4 h-4 text-[#800000]" />
              </div>
              
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 bg-[#800000] rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-lg group-hover:rotate-6 transition-transform">
                  {student.displayName?.[0] || student.username?.[0]?.toUpperCase()}
                </div>
                <div>
                  <h3 className="font-black text-[#800000] text-base tracking-tight">{student.displayName}</h3>
                  <p className="text-[10px] font-bold text-[#800000]/30 uppercase tracking-widest">{student.username}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-3 text-[#800000]/60">
                  <Mail className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-widest truncate">{student.email || 'no-email@dumila.ac.tz'}</span>
                </div>
                <div className="flex items-center gap-3 text-[#800000]/60">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Form 4A • Science</span>
                </div>
                <div className="flex items-center gap-3 text-[#800000]/60">
                  <Calendar className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Joined Jan 2026</span>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t-2 border-[#800000]/5 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-[9px] font-black uppercase tracking-widest text-green-600">Active</span>
                </div>
                <button className="text-[9px] font-black uppercase tracking-widest text-[#800000] hover:underline hover:text-[#daa520]">View Profile</button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
