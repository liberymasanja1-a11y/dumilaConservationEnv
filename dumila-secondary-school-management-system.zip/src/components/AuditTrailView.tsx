import React, { useEffect, useState } from 'react';
import { History, Search, Filter, User, Activity, Clock, ShieldCheck } from 'lucide-react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';

export default function AuditTrailView() {
  const { userData } = useAuth();
  const [logs, setLogs] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const isAdmin = userData?.role === 'admin';

  useEffect(() => {
    const q = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(100));
    const unsubLogs = onSnapshot(q, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubLogs();
      unsubUsers();
    };
  }, []);

  const filteredLogs = logs.filter(log => {
    const user = users.find(u => u.id === log.userId);
    const searchStr = `${log.action} ${log.details} ${user?.displayName || ''}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  if (!isAdmin) return <div className="p-8 text-center font-black uppercase tracking-widest text-red-500">Access Denied</div>;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic flex items-center gap-4">
          <ShieldCheck className="w-8 h-8 text-[#800000]" />
          System Audit Trail
        </h1>
        <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Activity monitoring and security logs</p>
      </header>

      <div className="bg-white rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] overflow-hidden">
        <div className="p-6 border-b-2 border-[#800000] bg-[#fdfcf0] flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
            <input
              type="text"
              placeholder="Search activity logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border-2 border-[#800000] rounded-xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
            />
          </div>
          <button className="px-6 py-3 bg-white border-2 border-[#800000] rounded-xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
            <Filter className="w-4 h-4" />
            <span>Filter</span>
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-[#fdfcf0] border-b-2 border-[#800000]">
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Timestamp</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">User</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Action</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#800000]/5">
              {filteredLogs.map((log) => {
                const user = users.find(u => u.id === log.userId);
                return (
                  <tr key={log.id} className="hover:bg-[#fdfcf0]/50 transition-colors group">
                    <td className="px-8 py-5 text-xs font-bold text-[#800000]/40">
                      <div className="flex items-center gap-2">
                        <Clock className="w-3 h-3" />
                        {new Date(log.timestamp).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-[#800000] rounded-lg flex items-center justify-center text-white text-[10px] font-black">
                          {user?.displayName?.[0] || 'S'}
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-[#800000]">{user?.displayName || 'System'}</span>
                          <span className="text-[9px] font-bold text-[#800000]/30 uppercase tracking-widest">{user?.role || 'Service'}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border-2 ${
                        log.action.includes('CREATE') ? 'bg-green-50 text-green-600 border-green-100' :
                        log.action.includes('DELETE') ? 'bg-red-50 text-red-600 border-red-100' :
                        'bg-blue-50 text-blue-600 border-blue-100'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <p className="text-sm font-bold text-[#800000]/60 leading-relaxed">{log.details}</p>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
