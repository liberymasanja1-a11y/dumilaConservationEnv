import React, { useEffect, useState } from 'react';
import { Bell, Calendar, Plus, Trash2, User, Megaphone, ArrowUpRight, Clock } from 'lucide-react';
import { collection, onSnapshot, addDoc, query, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';

export default function AnnouncementsView() {
  const { userData } = useAuth();
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newAnn, setNewAnn] = useState({ title: '', content: '' });
  const [loading, setLoading] = useState(false);

  const isStaff = userData?.role === 'admin' || userData?.role === 'teacher';

  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('date', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setAnnouncements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'announcements'), {
        ...newAnn,
        date: new Date().toISOString(),
        author: userData?.displayName || 'Staff'
      });
      setIsAdding(false);
      setNewAnn({ title: '', content: '' });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this announcement?')) return;
    try {
      await deleteDoc(doc(db, 'announcements', id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">School Notices</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Latest updates from the administration</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-[#800000] text-white font-black rounded-2xl flex items-center gap-2 hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-xl shadow-[#800000]/20 text-[10px] uppercase tracking-widest"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Notice</span>
          </button>
        )}
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)]"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-[#fdfcf0] rounded-xl flex items-center justify-center border-2 border-[#800000]">
                <Megaphone className="w-5 h-5 text-[#800000]" />
              </div>
              <h2 className="text-xl font-black uppercase tracking-tight text-[#800000]">Post Official Announcement</h2>
            </div>
            <form onSubmit={handleAdd} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Subject / Title</label>
                <input
                  type="text"
                  value={newAnn.title}
                  onChange={(e) => setNewAnn({ ...newAnn, title: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="e.g. Mid-Term Examination Schedule"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Announcement Body</label>
                <textarea
                  value={newAnn.content}
                  onChange={(e) => setNewAnn({ ...newAnn, content: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold min-h-[150px] text-[#800000] text-sm"
                  placeholder="Provide detailed information here..."
                  required
                />
              </div>
              <div className="flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-6 py-3 font-black text-[10px] uppercase tracking-widest text-[#800000]/40 hover:text-[#800000] transition-colors"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-10 py-4 bg-[#800000] text-white font-black rounded-2xl hover:bg-[#daa520] hover:text-[#800000] transition-all disabled:opacity-50 text-[10px] uppercase tracking-widest shadow-xl shadow-black/10"
                >
                  {loading ? 'Publishing...' : 'Publish Announcement'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 gap-6">
        {announcements.length === 0 ? (
          <div className="bg-white p-20 rounded-3xl border-2 border-dashed border-[#800000]/10 text-center">
            <div className="w-16 h-16 bg-[#fdfcf0] rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-[#800000]/10" />
            </div>
            <p className="text-sm font-black text-[#800000]/40 uppercase tracking-widest">No active announcements</p>
          </div>
        ) : (
          announcements.map((ann, i) => (
            <motion.div 
              key={ann.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] hover:shadow-[12px_12px_0px_0px_rgba(128,0,0,1)] transition-all relative overflow-hidden group"
            >
              <div className="absolute top-0 left-0 w-2 h-full bg-[#800000]" />
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-2 px-3 py-1 bg-[#fdfcf0] rounded-full border border-[#800000]/5">
                    <Calendar className="w-3 h-3 text-[#800000]" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-[#800000]/60">
                      {new Date(ann.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-[#fdfcf0] rounded-full border border-[#800000]/5">
                    <Clock className="w-3 h-3 text-[#800000]" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-[#800000]/60">
                      {new Date(ann.date).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-[#fdfcf0] rounded-full border border-[#800000]/5">
                    <User className="w-3 h-3 text-[#800000]" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-[#800000]/60">By {ann.author}</span>
                  </div>
                </div>
                {isStaff && (
                  <button
                    onClick={() => handleDelete(ann.id)}
                    className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-2xl font-black mb-4 text-[#800000] tracking-tight group-hover:text-[#daa520] transition-colors">{ann.title}</h3>
                  <p className="text-[#800000]/60 leading-relaxed font-medium text-sm max-w-3xl">{ann.content}</p>
                </div>
                <div className="hidden sm:block">
                  <div className="w-12 h-12 rounded-2xl bg-[#fdfcf0] border-2 border-[#800000] flex items-center justify-center group-hover:rotate-12 transition-transform">
                    <ArrowUpRight className="w-5 h-5 text-[#800000]" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
