import React from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  Bell, 
  LogOut, 
  Menu,
  X,
  User as UserIcon,
  Calendar,
  ClipboardCheck,
  Settings,
  ShieldCheck,
  ChevronRight,
  GraduationCap,
  Wallet,
  History,
  MessageSquare,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ChangePasswordModal from './ChangePasswordModal';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { userData, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = React.useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { icon: LayoutDashboard, label: 'Overview', path: '/dashboard', roles: ['admin', 'teacher', 'parent', 'student'] },
    { icon: Users, label: 'User Management', path: '/dashboard/users', roles: ['admin'] },
    { icon: GraduationCap, label: 'Students', path: '/dashboard/students', roles: ['admin', 'teacher'] },
    { icon: BookOpen, label: 'Classes', path: '/dashboard/classes', roles: ['admin', 'teacher'] },
    { icon: ClipboardCheck, label: 'Results', path: '/dashboard/results', roles: ['admin', 'teacher', 'parent', 'student'] },
    { icon: Wallet, label: 'Finances', path: '/dashboard/finances', roles: ['admin'] },
    { icon: MessageSquare, label: 'SMS Logs', path: '/dashboard/sms', roles: ['admin', 'teacher'] },
    { icon: History, label: 'Audit Trail', path: '/dashboard/audit', roles: ['admin'] },
    { icon: Calendar, label: 'Timetable', path: '/dashboard/timetable', roles: ['admin', 'teacher', 'parent', 'student'] },
    { icon: Bell, label: 'Announcements', path: '/dashboard/announcements', roles: ['admin', 'teacher', 'parent', 'student'] },
  ];

  const filteredNavItems = navItems.filter(item => item.roles.includes(userData?.role || ''));

  return (
    <div className="min-h-screen bg-[#fdfcf0] flex font-sans selection:bg-[#800000]/10 selection:text-[#800000]">
      {/* Mobile Sidebar Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-[#800000]/40 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-[#800000] text-white transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1)
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:relative lg:translate-x-0 border-r-4 border-[#DAA520]
      `}>
        <div className="p-8 flex items-center gap-4 border-b-2 border-white/10">
          <div className="w-12 h-12 bg-white border-2 border-[#DAA520] rounded-2xl flex items-center justify-center shadow-2xl shadow-[#800000]/20 rotate-3">
            <ShieldCheck className="w-6 h-6 text-[#800000]" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-black tracking-tighter uppercase italic">Dumila</span>
            <span className="text-[8px] font-black tracking-[0.4em] uppercase text-[#DAA520]">Portal System</span>
          </div>
        </div>

        <nav className="p-6 space-y-2">
          {filteredNavItems.map((item, index) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={index}
                to={item.path}
                onClick={() => setIsSidebarOpen(false)}
                className={`
                  flex items-center justify-between px-5 py-4 rounded-2xl transition-all group relative
                  ${isActive ? 'bg-[#daa520] text-[#800000] shadow-[6px_6px_0px_0px_rgba(255,255,255,0.2)]' : 'hover:bg-white/10 text-white/70 hover:text-white'}
                `}
              >
                <div className="flex items-center gap-4">
                  <item.icon className={`w-4 h-4 transition-colors ${isActive ? 'text-[#800000]' : 'text-white/40 group-hover:text-white'}`} />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.label}</span>
                </div>
                {isActive && <ChevronRight className="w-3 h-3 text-[#800000]/50" />}
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-8 border-t-2 border-white/10 bg-[#800000]">
          <div className="flex items-center gap-3 w-full text-white/20 font-black text-[9px] uppercase tracking-[0.3em]">
            &copy; 2026 Dumila Secondary
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-20 bg-white/95 backdrop-blur-md border-b-4 border-[#800000] flex items-center justify-between px-6 sticky top-0 z-30">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="lg:hidden p-3 bg-white border-2 border-[#800000] rounded-xl shadow-[4px_4px_0px_0px_rgba(218,165,32,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all"
          >
            {isSidebarOpen ? <X className="w-5 h-5 text-[#800000]" /> : <Menu className="w-5 h-5 text-[#800000]" />}
          </button>

          <div className="flex items-center gap-6 ml-auto">
            <div className="relative">
              <button 
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center gap-4 p-1.5 hover:bg-[#fdfcf0] rounded-2xl transition-all group border-2 border-transparent hover:border-[#800000]"
              >
                <div className="flex flex-col items-end hidden sm:flex">
                  <span className="text-sm font-black text-[#800000] tracking-tight">{userData?.displayName || userData?.username}</span>
                  <span className="text-[9px] font-black text-[#daa520] uppercase tracking-[0.3em]">{userData?.role}</span>
                </div>
                <div className="w-12 h-12 bg-[#800000] border-2 border-[#daa520] rounded-2xl flex items-center justify-center text-white font-black shadow-[6px_6px_0px_0px_rgba(218,165,32,1)] group-hover:rotate-6 transition-transform text-base">
                  {userData?.displayName?.[0] || userData?.username?.[0]?.toUpperCase()}
                </div>
              </button>

              <AnimatePresence>
                {isProfileMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 15, scale: 0.95 }}
                    className="absolute right-0 mt-4 w-72 bg-white rounded-3xl border-4 border-[#800000] shadow-[16px_16px_0px_0px_rgba(218,165,32,1)] z-[60] overflow-hidden"
                  >
                    <div className="p-8 bg-[#fdfcf0] border-b-4 border-[#800000]">
                      <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#800000]/30 mb-2">User Profile</p>
                      <p className="text-lg font-black text-[#800000] truncate tracking-tight uppercase italic">{userData?.displayName || userData?.username}</p>
                      <p className="text-[10px] font-bold text-[#800000]/40 truncate mt-1">{userData?.email}</p>
                    </div>
                    <div className="p-3 space-y-1">
                      <button
                        onClick={() => {
                          setIsPasswordModalOpen(true);
                          setIsProfileMenuOpen(false);
                        }}
                        className="flex items-center gap-4 w-full px-5 py-4 rounded-2xl hover:bg-[#800000] hover:text-white text-[#800000] transition-all font-black text-[10px] uppercase tracking-widest group"
                      >
                        <ShieldCheck className="w-5 h-5 text-[#800000] group-hover:text-white" />
                        <span>Security & Privacy</span>
                      </button>
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-4 w-full px-5 py-4 rounded-2xl hover:bg-[#daa520] hover:text-[#800000] text-red-600 transition-all font-black text-[10px] uppercase tracking-widest group"
                      >
                        <LogOut className="w-5 h-5 text-red-500 group-hover:text-[#800000]" />
                        <span>Terminate Session</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <div className="p-6 sm:p-10 lg:p-12 flex-1 min-h-0 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>

      <ChangePasswordModal 
        isOpen={isPasswordModalOpen} 
        onClose={() => setIsPasswordModalOpen(false)} 
      />
    </div>
  );
}

