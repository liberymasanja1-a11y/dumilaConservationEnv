import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock, ArrowRight, Loader2, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../lib/firebase';

const SchoolLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Gold Outer Circle Frame */}
    <circle cx="50" cy="50" r="48" fill="#FDFCF0" stroke="#B8860B" strokeWidth="3" />
    <circle cx="50" cy="50" r="44" stroke="#DAA520" strokeWidth="1" />
    
    {/* Sun Rays Background */}
    <g opacity="0.2">
      {[...Array(12)].map((_, i) => (
        <path key={i} d="M50 50 L100 50" stroke="#DAA520" strokeWidth="10" transform={`rotate(${i * 30} 50 50)`} />
      ))}
    </g>

    {/* Symbols Group */}
    <g transform="translate(0, 2)">
      {/* Book (Top Left) */}
      <g transform="translate(38, 12) scale(0.3)">
        <path d="M2 5 Q10 0 18 5 L18 22 Q10 17 2 22 Z" fill="#800000" />
        <path d="M20 5 Q28 0 36 5 L36 22 Q28 17 20 22 Z" fill="#800000" />
      </g>
      
      {/* Graduation Cap (Top Right) */}
      <g transform="translate(52, 10) scale(0.3)">
        <path d="M0 10 L18 0 L36 10 L18 20 Z" fill="#800000" />
        <path d="M8 12 L8 18 Q18 22 28 18 L28 12" fill="#800000" />
        <path d="M36 10 L36 20" stroke="#800000" strokeWidth="2" />
      </g>

      {/* Pupils */}
      <g>
        {/* Boy (Left) - White Shirt, Red Tie */}
        <path d="M25 80 Q25 45 42 45 L42 80 Z" fill="white" stroke="#ccc" strokeWidth="0.5" />
        <path d="M33 45 L35 55 L37 45 Z" fill="#800000" /> {/* Tie */}
        <circle cx="33" cy="38" r="7" fill="#4A3728" /> {/* Head */}
        
        {/* Girl (Right) - White Shirt, Red Skirt/Tie */}
        <path d="M75 80 Q75 45 58 45 L58 80 Z" fill="white" stroke="#ccc" strokeWidth="0.5" />
        <path d="M63 45 L65 55 L67 45 Z" fill="#800000" /> {/* Tie */}
        <circle cx="67" cy="38" r="7" fill="#4A3728" /> {/* Head */}
        <circle cx="67" cy="30" r="4" fill="#4A3728" /> {/* Bun */}
      </g>

      {/* Crossed Hammer and Hoe (Center) */}
      <g transform="translate(50, 60) scale(0.7) translate(-50, -45)">
        {/* Hammer */}
        <path d="M35 65 L65 35" stroke="#555" strokeWidth="6" strokeLinecap="round" />
        <path d="M60 30 L70 40 L65 45 L55 35 Z" fill="#333" />
        {/* Hoe (Jembe) */}
        <path d="M65 65 L35 35" stroke="#8B4513" strokeWidth="6" strokeLinecap="round" />
        <path d="M25 25 L45 25 L45 35 L25 35 Z" fill="#333" />
      </g>
    </g>

    {/* Red Banner/Ribbon for Motto */}
    <path d="M2 75 Q50 100 98 75 L95 85 Q50 110 5 85 Z" fill="#800000" stroke="#DAA520" strokeWidth="1" />
    
    {/* Motto Text */}
    <defs>
      <path id="mottoPathLogin" d="M10 82 Q50 105 90 82" />
    </defs>
    <text fill="white" fontSize="4.5" fontWeight="black" letterSpacing="0.2">
      <textPath href="#mottoPathLogin" startOffset="50%" textAnchor="middle">
        EDUCATION IS A KEY OF LIFE
      </textPath>
    </text>
  </svg>
);

export default function Login() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const email = identifier.includes('@') ? identifier : `${identifier.toLowerCase()}@dumila.ac.tz`;
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      let message = 'Invalid username or password. Please try again.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        message = 'Invalid credentials. Please check your username and password.';
      } else if (err.code === 'auth/too-many-requests') {
        message = 'Too many failed attempts. Please try again later.';
      }
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!identifier) {
      setError('Please enter your username or email to reset password.');
      return;
    }
    try {
      const email = identifier.includes('@') ? identifier : `${identifier.toLowerCase()}@dumila.ac.tz`;
      await sendPasswordResetEmail(auth, email);
      setResetSent(true);
      setError('');
    } catch (err: any) {
      console.error(err);
      setError('Failed to send reset email. Please check your username.');
    }
  };

  return (
    <div className="min-h-screen bg-[#fdfcf0] flex items-center justify-center p-4 sm:p-6 font-sans relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#800000]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#DAA520]/5 rounded-full blur-[150px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-[440px] bg-white border-4 border-[#800000] shadow-[16px_16px_0px_0px_rgba(218,165,32,1)] rounded-[2rem] overflow-hidden"
      >
        <div className="p-8 sm:p-10 text-center bg-white border-b-4 border-[#800000]">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <SchoolLogo className="w-16 h-16 sm:w-20 h-20" />
              <div className="absolute -bottom-1 -right-1 bg-[#800000] text-white p-1 rounded-lg border-2 border-[#800000] shadow-lg">
                <ShieldCheck className="w-3 h-3 sm:w-4 h-4" />
              </div>
            </div>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tighter uppercase italic text-[#800000]">SIGN IN</h2>
          <p className="text-[#daa520] text-[10px] font-black tracking-[0.4em] uppercase mt-2">Dumila Secondary School</p>
        </div>

        <div className="p-8 sm:p-10">
          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="mb-6 p-4 bg-red-50 text-[#800000] text-[10px] font-black rounded-xl border-2 border-[#800000] flex items-center gap-3"
              >
                <span className="uppercase tracking-widest leading-relaxed">{error}</span>
              </motion.div>
            )}
            {resetSent && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="mb-6 p-4 bg-green-50 text-green-700 text-[10px] font-black rounded-xl border-2 border-green-600 flex items-center gap-3"
              >
                <span className="uppercase tracking-widest leading-relaxed">Reset link sent to your email.</span>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black tracking-[0.2em] text-[#800000]/40 uppercase ml-1">
                Username or Email
              </label>
              <div className="relative group">
                <div className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#800000]/20 group-focus-within:text-[#daa520] transition-colors">
                  <User className="w-full h-full" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full pl-14 pr-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-xl focus:bg-white focus:ring-4 focus:ring-[#daa520]/5 transition-all outline-none font-bold text-[#800000] placeholder:text-[#800000]/20 text-sm"
                  placeholder="e.g. masanja.l"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-black tracking-[0.2em] text-[#800000]/40 uppercase ml-1">
                Password
              </label>
              <div className="relative group">
                <div className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#800000]/20 group-focus-within:text-[#daa520] transition-colors">
                  <Lock className="w-full h-full" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-14 pr-14 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-xl focus:bg-white focus:ring-4 focus:ring-[#daa520]/5 transition-all outline-none font-bold text-[#800000] placeholder:text-[#800000]/20 text-sm"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-5 top-1/2 -translate-y-1/2 p-1 text-[#800000]/20 hover:text-[#800000] transition-colors outline-none"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <motion.button
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-[#800000] text-white font-black text-[11px] tracking-[0.3em] rounded-xl shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] hover:bg-[#daa520] hover:text-[#800000] hover:shadow-[8px_8px_0px_0px_rgba(128,0,0,1)] transition-all flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed uppercase"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                <>
                  <span>Authenticate</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </motion.button>
          </form>

          <div className="mt-8 text-center">
            <button 
              type="button"
              onClick={handleResetPassword}
              className="text-[10px] font-black tracking-[0.2em] text-[#800000]/40 hover:text-[#daa520] transition-colors uppercase"
            >
              Forgot password?
            </button>
          </div>
        </div>

        <div className="p-6 bg-[#fdfcf0] border-t-4 border-[#800000] text-center">
          <p className="text-[9px] font-black tracking-[0.3em] text-[#800000]/30 uppercase">
            &copy; 2026 Dumila Secondary School Portal
          </p>
        </div>
      </motion.div>
    </div>
  );
}

