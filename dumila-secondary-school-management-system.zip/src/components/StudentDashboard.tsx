import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, Calendar, Bell, Award, GraduationCap, ArrowUpRight, Book, ClipboardList } from 'lucide-react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';

export default function StudentDashboard() {
  const { userData } = useAuth();
  const [noticesCount, setNoticesCount] = React.useState(0);

  React.useEffect(() => {
    const unsub = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      setNoticesCount(snapshot.size);
    });
    return () => unsub();
  }, []);

  const stats = [
    { label: 'Academic Rank', value: '5th / 45', icon: Award, color: 'bg-yellow-500' },
    { label: 'Attendance', value: '94%', icon: GraduationCap, color: 'bg-green-500' },
    { label: 'New Notices', value: noticesCount, icon: Bell, color: 'bg-red-500' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase">Student Portal</h1>
          <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">Your academic journey at Dumila Secondary</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-white rounded-2xl border-2 border-[#1a1a1a] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
          <Book className="w-4 h-4 text-[#800000]" />
          <span className="text-[10px] font-black text-[#1a1a1a] uppercase tracking-widest">Form 4A • Science</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] hover:shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-2xl ${stat.color} text-white shadow-lg`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a] transition-colors" />
            </div>
            <h3 className="text-[10px] font-black text-[#1a1a1a]/40 uppercase tracking-[0.2em] mb-1">{stat.label}</h3>
            <p className="text-4xl font-black text-[#1a1a1a] tracking-tighter">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)]">
            <h2 className="text-xl font-black text-[#1a1a1a] uppercase tracking-tight mb-8">Today's Timetable</h2>
            <div className="space-y-4">
              {[
                { time: '08:00 AM', subject: 'Mathematics', teacher: 'Mr. Masanja', room: 'Room 12' },
                { time: '10:30 AM', subject: 'Biology', teacher: 'Ms. Juma', room: 'Lab 1' },
                { time: '01:00 PM', subject: 'English', teacher: 'Mrs. Bakari', room: 'Room 5' }
              ].map((session, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#f8f8f6] transition-colors group border border-transparent hover:border-[#1a1a1a]/5">
                  <div className="w-16 text-center">
                    <p className="text-[10px] font-black text-[#800000] uppercase tracking-tighter">{session.time}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-black text-[#1a1a1a]">{session.subject}</p>
                    <p className="text-[10px] font-bold text-[#1a1a1a]/30 uppercase tracking-widest">{session.teacher} • {session.room}</p>
                  </div>
                  <div className="px-3 py-1 bg-[#1a1a1a] text-white text-[8px] font-black uppercase tracking-widest rounded-full">
                    Active
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-[#DAA520] p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] text-[#1a1a1a]">
            <h2 className="text-xl font-black uppercase tracking-tight mb-2">Quick Links</h2>
            <p className="text-xs font-bold text-[#1a1a1a]/40 uppercase tracking-widest mb-8">Access your resources</p>
            <div className="space-y-3">
              <button className="flex items-center justify-between w-full p-4 bg-white rounded-2xl border-2 border-[#1a1a1a] hover:translate-x-1 transition-transform group">
                <div className="flex items-center gap-3">
                  <ClipboardList className="w-5 h-5 text-[#800000]" />
                  <span className="text-[10px] font-black uppercase tracking-widest">View Results</span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a]" />
              </button>
              <button className="flex items-center justify-between w-full p-4 bg-white rounded-2xl border-2 border-[#1a1a1a] hover:translate-x-1 transition-transform group">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Full Timetable</span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a]" />
              </button>
              <button className="flex items-center justify-between w-full p-4 bg-white rounded-2xl border-2 border-[#1a1a1a] hover:translate-x-1 transition-transform group">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-orange-600" />
                  <span className="text-[10px] font-black uppercase tracking-widest">All Notices</span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
