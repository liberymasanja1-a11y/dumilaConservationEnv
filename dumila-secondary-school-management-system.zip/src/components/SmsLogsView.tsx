import React, { useEffect, useState } from 'react';
import { MessageSquare, Search, Filter, Clock, Send, CheckCircle2 } from 'lucide-react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';

export default function SmsLogsView() {
  const { userData } = useAuth();
  const [logs, setLogs] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const isStaff = userData?.role === 'admin' || userData?.role === 'teacher';

  useEffect(() => {
    const q = query(collection(db, 'smsLogs'), orderBy('timestamp', 'desc'), limit(100));
    const unsub = onSnapshot(q, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const filteredLogs = logs.filter(log => {
    const searchStr = `${log.recipient} ${log.message} ${log.type}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  if (!isStaff) return <div className="p-8 text-center font-black uppercase tracking-widest text-red-500">Access Denied</div>;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase italic flex items-center gap-4">
          <MessageSquare className="w-8 h-8 text-[#800000]" />
          Communication Logs
        </h1>
        <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">SMS notification history</p>
      </header>

      <div className="bg-white rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden">
        <div className="p-6 border-b-2 border-[#1a1a1a] bg-[#fdfcf0] flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#1a1a1a]/20" />
            <input
              type="text"
              placeholder="Search SMS logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border-2 border-[#1a1a1a] rounded-xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
            />
          </div>
          <button className="px-6 py-3 bg-white border-2 border-[#1a1a1a] rounded-xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#f8f8f6] transition-all">
            <Filter className="w-4 h-4" />
            <span>Filter</span>
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-[#fdfcf0] border-b-2 border-[#1a1a1a]">
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Timestamp</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Recipient</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Type</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Message</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#1a1a1a]/5">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-[#fdfcf0]/50 transition-colors group">
                  <td className="px-8 py-5 text-xs font-bold text-[#1a1a1a]/40">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="text-sm font-black text-[#1a1a1a]">{log.recipient}</span>
                  </td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1 bg-[#fdfcf0] border-2 border-[#1a1a1a] rounded-lg text-[9px] font-black uppercase tracking-widest">
                      {log.type}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-bold text-[#1a1a1a]/60 max-w-md line-clamp-2">{log.message}</p>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2 text-green-600">
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase tracking-widest">{log.status}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
