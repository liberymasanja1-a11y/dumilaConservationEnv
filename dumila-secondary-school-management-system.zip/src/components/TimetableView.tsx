import React, { useEffect, useState } from 'react';
import { Calendar, Plus, Trash2, Clock, MapPin, User, ArrowUpRight, GraduationCap } from 'lucide-react';
import { collection, onSnapshot, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';

export default function TimetableView() {
  const { userData } = useAuth();
  const [timetable, setTimetable] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newEntry, setNewEntry] = useState({ day: 'Monday', period: '1', subject: '', teacher: '', room: '' });
  const [loading, setLoading] = useState(false);

  const isAdmin = userData?.role === 'admin';

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'timetable'), (snapshot) => {
      setTimetable(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'timetable'), newEntry);
      setIsAdding(false);
      setNewEntry({ day: 'Monday', period: '1', subject: '', teacher: '', room: '' });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this schedule entry?')) return;
    try {
      await deleteDoc(doc(db, 'timetable', id));
    } catch (err) {
      console.error(err);
    }
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const periods = ['1', '2', '3', '4', '5', '6'];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase italic">School Timetable</h1>
          <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">Weekly academic schedule</p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-[#800000] text-white font-black rounded-2xl flex items-center gap-2 hover:bg-black transition-all shadow-xl shadow-[#800000]/20 text-[10px] uppercase tracking-widest active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Schedule Entry</span>
          </button>
        )}
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)]"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-[#fdfcf0] rounded-xl flex items-center justify-center border-2 border-[#1a1a1a]">
                <Clock className="w-5 h-5 text-[#800000]" />
              </div>
              <h2 className="text-xl font-black uppercase tracking-tight">Schedule New Session</h2>
            </div>
            <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Day of Week</label>
                <select
                  value={newEntry.day}
                  onChange={(e) => setNewEntry({ ...newEntry, day: e.target.value })}
                  className="w-full px-4 py-4 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
                  required
                >
                  {days.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Period</label>
                <select
                  value={newEntry.period}
                  onChange={(e) => setNewEntry({ ...newEntry, period: e.target.value })}
                  className="w-full px-4 py-4 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
                  required
                >
                  {periods.map(p => <option key={p} value={p}>Period {p}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Subject</label>
                <input
                  type="text"
                  value={newEntry.subject}
                  onChange={(e) => setNewEntry({ ...newEntry, subject: e.target.value })}
                  className="w-full px-4 py-4 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
                  placeholder="e.g. Mathematics"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Teacher</label>
                <input
                  type="text"
                  value={newEntry.teacher}
                  onChange={(e) => setNewEntry({ ...newEntry, teacher: e.target.value })}
                  className="w-full px-4 py-4 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
                  placeholder="e.g. Mr. Masanja"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">Room / Lab</label>
                <input
                  type="text"
                  value={newEntry.room}
                  onChange={(e) => setNewEntry({ ...newEntry, room: e.target.value })}
                  className="w-full px-4 py-4 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl focus:ring-4 focus:ring-[#800000]/10 outline-none font-bold text-sm"
                  placeholder="e.g. Room 101"
                  required
                />
              </div>
              <div className="md:col-span-3 flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-6 py-3 font-black text-[10px] uppercase tracking-widest text-[#1a1a1a]/40 hover:text-[#1a1a1a] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-10 py-4 bg-[#1a1a1a] text-white font-black rounded-2xl hover:bg-[#800000] transition-all disabled:opacity-50 text-[10px] uppercase tracking-widest shadow-xl shadow-black/10"
                >
                  {loading ? 'Processing...' : 'Confirm Schedule'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-[#fdfcf0] border-b-2 border-[#1a1a1a]">
                <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40 w-24">Period</th>
                {days.map(day => (
                  <th key={day} className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]/40">{day}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#1a1a1a]/5">
              {periods.map(period => (
                <tr key={period} className="hover:bg-[#fdfcf0]/30 transition-colors group">
                  <td className="px-8 py-6 bg-[#f8f8f6]/30 border-r-2 border-[#1a1a1a]/5">
                    <div className="flex flex-col items-center">
                      <span className="text-lg font-black text-[#1a1a1a] tracking-tighter">P{period}</span>
                      <span className="text-[8px] font-bold text-[#1a1a1a]/30 uppercase tracking-widest">Session</span>
                    </div>
                  </td>
                  {days.map(day => {
                    const entry = timetable.find(t => t.day === day && t.period === period);
                    return (
                      <td key={day} className="px-4 py-4 min-w-[180px]">
                        {entry ? (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="relative group/item"
                          >
                            <div className="p-4 bg-white border-2 border-[#1a1a1a] rounded-2xl shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] group-hover/item:shadow-[4px_4px_0px_0px_rgba(128,0,0,1)] transition-all group-hover/item:-translate-y-1">
                              <div className="flex items-center justify-between mb-2">
                                <p className="text-sm font-black text-[#1a1a1a] tracking-tight">{entry.subject}</p>
                                <ArrowUpRight className="w-3 h-3 text-[#1a1a1a]/20 group-hover/item:text-[#800000]" />
                              </div>
                              <div className="space-y-1.5">
                                <div className="flex items-center gap-1.5">
                                  <User className="w-3 h-3 text-[#800000]" />
                                  <span className="text-[9px] font-bold text-[#1a1a1a]/60 uppercase tracking-widest truncate">{entry.teacher}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <MapPin className="w-3 h-3 text-[#DAA520]" />
                                  <span className="text-[9px] font-bold text-[#1a1a1a]/60 uppercase tracking-widest">{entry.room}</span>
                                </div>
                              </div>
                            </div>
                            {isAdmin && (
                              <button
                                onClick={() => handleDelete(entry.id)}
                                className="absolute -top-2 -right-2 p-1.5 bg-white text-red-500 border-2 border-[#1a1a1a] rounded-xl shadow-lg opacity-0 group-hover/item:opacity-100 transition-opacity hover:bg-red-50"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </motion.div>
                        ) : (
                          <div className="h-24 border-2 border-dashed border-[#1a1a1a]/5 rounded-2xl flex items-center justify-center group-hover:border-[#1a1a1a]/10 transition-colors">
                            <Clock className="w-5 h-5 text-[#1a1a1a]/5" />
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
