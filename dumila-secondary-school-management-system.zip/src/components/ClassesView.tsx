import React from 'react';
import { BookOpen, Users, Clock, GraduationCap, ArrowUpRight, Search, Filter, Plus } from 'lucide-react';
import { motion } from 'motion/react';

export default function ClassesView() {
  const classes = [
    { name: 'Form 1A', students: 45, teacher: 'Mr. Juma', subject: 'Mathematics', room: 'Room 12' },
    { name: 'Form 2B', students: 42, teacher: 'Ms. Sarah', subject: 'English', room: 'Room 5' },
    { name: 'Form 3A', students: 38, teacher: 'Mr. Peter', subject: 'Physics', room: 'Lab 2' },
    { name: 'Form 4C', students: 40, teacher: 'Ms. Mary', subject: 'Biology', room: 'Lab 1' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">Class Management</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Academic structure and organization</p>
        </div>
        <button className="px-6 py-3 bg-[#800000] text-white font-black rounded-2xl flex items-center gap-2 hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-xl shadow-black/10 text-[10px] uppercase tracking-widest active:scale-95">
          <Plus className="w-4 h-4" />
          <span>Add New Class</span>
        </button>
      </header>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
          <input
            type="text"
            placeholder="Search classes or teachers..."
            className="w-full pl-12 pr-4 py-4 bg-white border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
          />
        </div>
        <button className="px-6 py-4 bg-white border-2 border-[#800000] rounded-2xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
          <Filter className="w-4 h-4" />
          <span>Filter</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {classes.map((cls, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] hover:shadow-[12px_12px_0px_0px_rgba(128,0,0,1)] transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-opacity">
              <ArrowUpRight className="w-5 h-5 text-[#800000]" />
            </div>

            <div className="flex items-center justify-between mb-8">
              <div className="w-16 h-16 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl flex items-center justify-center text-[#800000] shadow-lg group-hover:rotate-6 transition-transform">
                <BookOpen className="w-8 h-8" />
              </div>
              <div className="text-right">
                <span className="px-3 py-1 bg-[#800000] text-white rounded-full text-[8px] font-black uppercase tracking-[0.2em]">
                  2026 Academic
                </span>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-3xl font-black text-[#800000] tracking-tighter mb-1 uppercase">{cls.name}</h3>
              <p className="text-[10px] font-black text-[#daa520] uppercase tracking-[0.3em]">{cls.subject}</p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 pt-8 border-t-2 border-[#800000]/5">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-[#800000]/30">
                  <Users className="w-3 h-3" />
                  <span className="text-[8px] font-black uppercase tracking-widest">Students</span>
                </div>
                <p className="text-sm font-black text-[#800000]">{cls.students}</p>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-[#800000]/30">
                  <Clock className="w-3 h-3" />
                  <span className="text-[8px] font-black uppercase tracking-widest">Teacher</span>
                </div>
                <p className="text-sm font-black text-[#800000] truncate">{cls.teacher}</p>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-[#800000]/30">
                  <GraduationCap className="w-3 h-3" />
                  <span className="text-[8px] font-black uppercase tracking-widest">Room</span>
                </div>
                <p className="text-sm font-black text-[#800000]">{cls.room}</p>
              </div>
            </div>

            <div className="mt-8">
              <button className="w-full py-3 bg-[#fdfcf0] border-2 border-[#800000] rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-[#800000] hover:text-white transition-all text-[#800000]">
                View Class Details
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
