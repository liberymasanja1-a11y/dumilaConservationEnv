import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, Users, ClipboardCheck, Bell, GraduationCap, Calendar, ArrowUpRight } from 'lucide-react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';

export default function TeacherDashboard() {
  const { userData } = useAuth();
  const [studentCount, setStudentCount] = React.useState(0);
  const [announcementCount, setAnnouncementCount] = React.useState(0);

  React.useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setStudentCount(snapshot.docs.filter(doc => doc.data().role === 'student').length);
    });
    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      setAnnouncementCount(snapshot.size);
    });
    return () => {
      unsubUsers();
      unsubAnnouncements();
    };
  }, []);

  const stats = [
    { label: 'Total Students', value: studentCount, icon: Users, color: 'bg-blue-500' },
    { label: 'Notices', value: announcementCount, icon: Bell, color: 'bg-orange-500' },
    { label: 'My Classes', value: '4', icon: BookOpen, color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase italic">Teacher Portal</h1>
          <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">Manage your academic activities</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-white rounded-2xl border-2 border-[#1a1a1a] shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
          <GraduationCap className="w-4 h-4 text-[#800000]" />
          <span className="text-[10px] font-black text-[#1a1a1a] uppercase tracking-widest">Academic Year 2026</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] hover:shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-2xl ${stat.color} text-white shadow-lg`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a] transition-colors" />
            </div>
            <h3 className="text-[10px] font-black text-[#1a1a1a]/40 uppercase tracking-[0.2em] mb-1">{stat.label}</h3>
            <p className="text-4xl font-black text-[#1a1a1a] tracking-tighter">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)]">
          <h2 className="text-xl font-black text-[#1a1a1a] uppercase tracking-tight mb-8">My Schedule Today</h2>
          <div className="space-y-4">
            {[
              { time: '08:00 AM', subject: 'Mathematics', class: 'Form 4A', room: 'Room 12' },
              { time: '10:30 AM', subject: 'Physics', class: 'Form 3B', room: 'Lab 2' },
              { time: '01:00 PM', subject: 'Mathematics', class: 'Form 2C', room: 'Room 5' }
            ].map((session, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#f8f8f6] transition-colors group border border-transparent hover:border-[#1a1a1a]/5">
                <div className="w-16 text-center">
                  <p className="text-[10px] font-black text-[#800000] uppercase tracking-tighter">{session.time}</p>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-black text-[#1a1a1a]">{session.subject}</p>
                  <p className="text-[10px] font-bold text-[#1a1a1a]/30 uppercase tracking-widest">{session.class} • {session.room}</p>
                </div>
                <div className="px-3 py-1 bg-[#1a1a1a] text-white text-[8px] font-black uppercase tracking-widest rounded-full">
                  Upcoming
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1a1a1a] p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] text-white">
          <h2 className="text-xl font-black uppercase tracking-tight mb-2">Teacher Actions</h2>
          <p className="text-xs font-bold text-white/40 uppercase tracking-widest mb-8">Quick access to management tools</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button className="p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all group text-left">
              <ClipboardCheck className="w-6 h-6 text-[#DAA520] mb-3 group-hover:scale-110 transition-transform" />
              <p className="text-[10px] font-black uppercase tracking-widest">Enter Results</p>
              <p className="text-[9px] font-bold text-white/30 mt-1">Upload student grades</p>
            </button>
            <button className="p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all group text-left">
              <Calendar className="w-6 h-6 text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
              <p className="text-[10px] font-black uppercase tracking-widest">My Timetable</p>
              <p className="text-[9px] font-bold text-white/30 mt-1">View teaching schedule</p>
            </button>
            <button className="p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all group text-left">
              <Users className="w-6 h-6 text-green-400 mb-3 group-hover:scale-110 transition-transform" />
              <p className="text-[10px] font-black uppercase tracking-widest">Student List</p>
              <p className="text-[9px] font-bold text-white/30 mt-1">View class registers</p>
            </button>
            <button className="p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all group text-left">
              <Bell className="w-6 h-6 text-orange-400 mb-3 group-hover:scale-110 transition-transform" />
              <p className="text-[10px] font-black uppercase tracking-widest">Post Notice</p>
              <p className="text-[9px] font-bold text-white/30 mt-1">Notify your students</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
