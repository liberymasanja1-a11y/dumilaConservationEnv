import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Users, ClipboardCheck, Bell, CreditCard, ArrowUpRight, GraduationCap, Calendar, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

export default function ParentDashboard() {
  const { userData } = useAuth();
  
  return (
    <div className="space-y-10">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase italic">Parent Portal</h1>
          <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">Academic progress monitoring</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-[#fdfcf0] border-2 border-[#1a1a1a] rounded-2xl">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-widest">Live Updates Active</span>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Student Profile Card */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 bg-white p-10 rounded-[2.5rem] border-2 border-[#1a1a1a] shadow-[12px_12px_0px_0px_rgba(26,26,26,1)] relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-100 transition-opacity">
            <ArrowUpRight className="w-8 h-8 text-[#1a1a1a]" />
          </div>

          <div className="flex flex-col md:flex-row items-center md:items-start gap-8 mb-12">
            <div className="w-24 h-24 bg-[#1a1a1a] rounded-3xl flex items-center justify-center text-white font-black text-4xl shadow-2xl rotate-3 group-hover:rotate-0 transition-transform">
              JD
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-4xl font-black text-[#1a1a1a] tracking-tighter uppercase mb-2">John Doe Jr.</h3>
              <div className="flex flex-wrap justify-center md:justify-start gap-3">
                <span className="px-3 py-1 bg-[#800000] text-white rounded-full text-[9px] font-black uppercase tracking-widest">Form 2A</span>
                <span className="px-3 py-1 bg-[#DAA520] text-white rounded-full text-[9px] font-black uppercase tracking-widest">Science Stream</span>
                <span className="px-3 py-1 bg-[#f8f8f6] border border-[#1a1a1a]/10 rounded-full text-[9px] font-black uppercase tracking-widest">ID: 2026-042</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-[#fdfcf0] border-2 border-[#1a1a1a] rounded-3xl group/stat hover:-translate-y-1 transition-transform">
              <div className="flex items-center justify-between mb-4">
                <TrendingUp className="w-5 h-5 text-[#800000]" />
                <span className="text-[10px] font-black text-[#1a1a1a]/30 uppercase tracking-widest">Performance</span>
              </div>
              <p className="text-4xl font-black text-[#1a1a1a] tracking-tighter">78.4%</p>
              <p className="text-[9px] font-bold text-green-600 uppercase tracking-widest mt-1">+2.1% from last term</p>
            </div>
            <div className="p-6 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-3xl group/stat hover:-translate-y-1 transition-transform">
              <div className="flex items-center justify-between mb-4">
                <Calendar className="w-5 h-5 text-[#DAA520]" />
                <span className="text-[10px] font-black text-[#1a1a1a]/30 uppercase tracking-widest">Attendance</span>
              </div>
              <p className="text-4xl font-black text-[#1a1a1a] tracking-tighter">95.2%</p>
              <p className="text-[9px] font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">Excellent consistency</p>
            </div>
          </div>
        </motion.div>

        {/* Quick Actions / Notifications */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-[#1a1a1a] p-10 rounded-[2.5rem] text-white shadow-[12px_12px_0px_0px_rgba(128,0,0,1)]"
        >
          <h3 className="text-2xl font-black uppercase tracking-tight mb-8 italic">Recent Results</h3>
          <div className="space-y-6">
            {[
              { sub: 'Mathematics', score: '85', total: '100', color: 'bg-green-500' },
              { sub: 'English', score: '72', total: '100', color: 'bg-yellow-500' },
              { sub: 'Physics', score: '68', total: '100', color: 'bg-orange-500' },
              { sub: 'Kiswahili', score: '91', total: '100', color: 'bg-green-500' }
            ].map((res, i) => (
              <div key={i} className="group/res cursor-pointer">
                <div className="flex justify-between items-end mb-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/40 group-hover/res:text-white transition-colors">{res.sub}</span>
                  <span className="text-sm font-black tracking-tighter">{res.score}/{res.total}</span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${res.score}%` }}
                    transition={{ delay: 0.5 + (i * 0.1), duration: 1 }}
                    className={`h-full ${res.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
          
          <button className="w-full mt-10 py-4 bg-white text-[#1a1a1a] font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-[#DAA520] transition-all active:scale-95">
            Download Full Report
          </button>
        </motion.div>
      </div>

      {/* Upcoming Events */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: Bell, title: 'Parent Meeting', date: 'Oct 24, 2026', time: '10:00 AM' },
          { icon: CreditCard, title: 'Fee Payment', date: 'Nov 01, 2026', time: 'Due Date' },
          { icon: GraduationCap, title: 'Graduation', date: 'Dec 15, 2026', time: 'Main Hall' }
        ].map((event, i) => (
          <motion.div 
            key={i}
            whileHover={{ y: -5 }}
            className="p-6 bg-white border-2 border-[#1a1a1a] rounded-3xl flex items-center gap-4 group cursor-pointer"
          >
            <div className="w-12 h-12 bg-[#f8f8f6] border-2 border-[#1a1a1a] rounded-2xl flex items-center justify-center group-hover:bg-[#1a1a1a] group-hover:text-white transition-all">
              <event.icon className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-black text-[#1a1a1a] text-sm uppercase tracking-tight">{event.title}</h4>
              <p className="text-[9px] font-bold text-[#1a1a1a]/40 uppercase tracking-widest">{event.date} • {event.time}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
