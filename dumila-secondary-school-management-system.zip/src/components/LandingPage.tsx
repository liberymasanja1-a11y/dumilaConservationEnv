import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Instagram, Twitter, Facebook, MessageCircle, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const SchoolLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Gold Outer Circle Frame */}
    <circle cx="50" cy="50" r="48" fill="#FDFCF0" stroke="#B8860B" strokeWidth="3" />
    <circle cx="50" cy="50" r="44" stroke="#DAA520" strokeWidth="1" />
    
    {/* Sun Rays Background */}
    <g opacity="0.2">
      {[...Array(12)].map((_, i) => (
        <path key={i} d="M50 50 L100 50" stroke="#DAA520" strokeWidth="10" transform={`rotate(${i * 30} 50 50)`} />
      ))}
    </g>

    {/* Symbols Group */}
    <g transform="translate(0, 2)">
      {/* Book (Top Left) */}
      <g transform="translate(38, 12) scale(0.3)">
        <path d="M2 5 Q10 0 18 5 L18 22 Q10 17 2 22 Z" fill="#800000" />
        <path d="M20 5 Q28 0 36 5 L36 22 Q28 17 20 22 Z" fill="#800000" />
      </g>
      
      {/* Graduation Cap (Top Right) */}
      <g transform="translate(52, 10) scale(0.3)">
        <path d="M0 10 L18 0 L36 10 L18 20 Z" fill="#800000" />
        <path d="M8 12 L8 18 Q18 22 28 18 L28 12" fill="#800000" />
        <path d="M36 10 L36 20" stroke="#800000" strokeWidth="2" />
      </g>

      {/* Pupils */}
      <g>
        {/* Boy (Left) - White Shirt, Red Tie */}
        <path d="M25 80 Q25 45 42 45 L42 80 Z" fill="white" stroke="#ccc" strokeWidth="0.5" />
        <path d="M33 45 L35 55 L37 45 Z" fill="#800000" /> {/* Tie */}
        <circle cx="33" cy="38" r="7" fill="#4A3728" /> {/* Head */}
        
        {/* Girl (Right) - White Shirt, Red Skirt/Tie */}
        <path d="M75 80 Q75 45 58 45 L58 80 Z" fill="white" stroke="#ccc" strokeWidth="0.5" />
        <path d="M63 45 L65 55 L67 45 Z" fill="#800000" /> {/* Tie */}
        <circle cx="67" cy="38" r="7" fill="#4A3728" /> {/* Head */}
        <circle cx="67" cy="30" r="4" fill="#4A3728" /> {/* Bun */}
      </g>

      {/* Crossed Hammer and Hoe (Center) */}
      <g transform="translate(50, 60) scale(0.7) translate(-50, -45)">
        {/* Hammer */}
        <path d="M35 65 L65 35" stroke="#555" strokeWidth="6" strokeLinecap="round" />
        <path d="M60 30 L70 40 L65 45 L55 35 Z" fill="#333" />
        {/* Hoe (Jembe) */}
        <path d="M65 65 L35 35" stroke="#8B4513" strokeWidth="6" strokeLinecap="round" />
        <path d="M25 25 L45 25 L45 35 L25 35 Z" fill="#333" />
      </g>
    </g>

    {/* Red Banner/Ribbon for Motto */}
    <path d="M2 75 Q50 100 98 75 L95 85 Q50 110 5 85 Z" fill="#800000" stroke="#DAA520" strokeWidth="1" />
    
    {/* Motto Text */}
    <defs>
      <path id="mottoPath" d="M10 82 Q50 105 90 82" />
    </defs>
    <text fill="white" fontSize="4.5" fontWeight="black" letterSpacing="0.2">
      <textPath href="#mottoPath" startOffset="50%" textAnchor="middle">
        EDUCATION IS A KEY OF LIFE
      </textPath>
    </text>
  </svg>
);

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-[#fdfcf0] font-display text-[#800000] selection:bg-[#800000]/20 selection:text-[#800000]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b-4 border-[#800000] px-6 md:px-12 py-5">
        <div className="max-w-[100rem] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4 md:gap-6">
            <SchoolLogo className="w-12 h-12 md:w-14 h-14" />
            <div className="flex flex-col">
              <span className="text-xl md:text-2xl font-black tracking-tighter uppercase leading-none text-[#800000]">Dumila</span>
              <span className="text-[10px] font-black tracking-[0.3em] uppercase text-[#daa520]">Secondary School</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10 text-sm font-black tracking-[0.1em]">
            <a href="#about" className="text-[#800000] hover:text-[#daa520] transition-colors uppercase">About</a>
            <a href="#contact" className="text-[#800000] hover:text-[#daa520] transition-colors uppercase">Contact</a>
            <Link to="/login" className="px-10 py-4 bg-[#800000] text-white rounded-2xl hover:bg-[#daa520] transition-all shadow-[6px_6px_0px_0px_rgba(218,165,32,1)] active:translate-x-1 active:translate-y-1 active:shadow-none uppercase text-xs tracking-widest">
              Portal Login
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-3 bg-white border-2 border-[#800000] rounded-xl shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]"
          >
            {isMenuOpen ? <X className="w-6 h-6 text-[#800000]" /> : <Menu className="w-6 h-6 text-[#800000]" />}
          </button>
        </div>

        {/* Mobile Nav Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 right-0 bg-white border-b-4 border-[#800000] p-8 md:hidden flex flex-col gap-6"
            >
              <a href="#about" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-tighter text-[#800000]">About</a>
              <a href="#contact" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-tighter text-[#800000]">Contact</a>
              <Link to="/login" className="w-full py-5 bg-[#800000] text-white text-center font-black rounded-2xl uppercase tracking-widest shadow-[6px_6px_0px_0px_rgba(218,165,32,1)]">
                Portal Login
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-48 pb-32 px-8 overflow-hidden">
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-4 px-6 py-3 bg-[#800000] text-white font-black text-[10px] tracking-[0.4em] mb-12 shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] uppercase">
              Registration open 2026
            </div>
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-black leading-[0.9] mb-10 tracking-tighter uppercase italic text-[#800000]">
              Education is <br />
              <span className="text-[#daa520] drop-shadow-[4px_4px_0px_#800000]">a key of life</span>
            </h1>
            <p className="text-lg md:text-2xl text-[#800000]/60 mb-12 max-w-3xl mx-auto leading-relaxed font-bold tracking-tight">
              Empowering the next generation of leaders in Morogoro through absolute academic excellence and discipline.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link to="/login" className="w-full sm:w-auto px-12 py-6 bg-[#800000] text-white font-black rounded-3xl text-lg uppercase tracking-widest shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] hover:bg-[#daa520] transition-all hover:-translate-y-1">
                Access Portal
              </Link>
              <a href="#about" className="w-full sm:w-auto px-12 py-6 bg-white text-[#800000] border-4 border-[#800000] font-black rounded-3xl text-lg uppercase tracking-widest hover:bg-[#fdfcf0] transition-all">
                Learn More
              </a>
            </div>
          </motion.div>
        </div>

        {/* Background Elements */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-[#DAA520]/10 rounded-full blur-[120px] -z-10" />
        <div className="absolute bottom-0 right-0 translate-x-1/4 w-[600px] h-[600px] bg-[#800000]/5 rounded-full blur-[150px] -z-10" />
      </header>

      {/* Stats Section */}
      <section className="px-8 py-32 bg-[#800000] text-white overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            { label: 'Curriculum', val: 'Form 1-4', desc: 'Comprehensive secondary education following national standards.' },
            { label: 'Community', val: '1000+', desc: 'A vibrant community of students, teachers, and parents.' },
            { label: 'Success', val: '2026', desc: 'Preparing students for the challenges of the modern world.' }
          ].map((stat, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="group text-center flex flex-col items-center border-4 border-white/10 p-12 rounded-[3rem] hover:border-[#DAA520] transition-colors relative"
            >
              <div className="w-24 h-24 bg-white text-[#800000] rounded-3xl flex items-center justify-center mb-10 shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] group-hover:rotate-6 transition-transform">
                <SchoolLogo className="w-12 h-12" />
              </div>
              <p className="text-[10px] font-black tracking-[0.3em] text-white/40 mb-4 uppercase">{stat.label}</p>
              <h3 className="text-5xl font-black mb-4 tracking-tighter uppercase italic">{stat.val}</h3>
              <p className="text-lg leading-tight font-bold text-white/60">{stat.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="px-8 py-32">
        <div className="max-w-5xl mx-auto text-center">
          <span className="text-[10px] font-black tracking-[0.5em] text-[#800000] mb-6 block uppercase">Our Philosophy</span>
          <h2 className="text-5xl md:text-7xl font-black mb-12 tracking-tighter leading-[0.9] uppercase italic text-[#800000]">Modern Education <br/> Absolute Discipline</h2>
          <p className="text-xl md:text-2xl text-[#800000]/60 mb-16 leading-relaxed font-bold max-w-3xl mx-auto">
            Dumila Secondary School is dedicated to providing a transformative educational experience. Our digital portal streamlines school life for everyone.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { title: 'Academic Tracking', desc: 'Real-time NECTA standard result monitoring.' },
              { title: 'Financial Transparency', desc: 'Government capitation fund tracking.' },
              { title: 'Instant SMS', desc: 'Direct communication with parents and staff.' },
              { title: 'Secure Audit', desc: 'Full activity logging and data integrity.' }
            ].map((item, i) => (
              <div key={i} className="p-10 bg-white text-[#800000] rounded-[2.5rem] border-4 border-[#800000] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] flex flex-col items-center gap-6 group hover:-translate-y-2 transition-transform">
                <div className="w-16 h-16 bg-[#fdfcf0] rounded-2xl flex items-center justify-center border-2 border-[#800000] group-hover:bg-[#daa520] group-hover:text-[#800000] transition-colors">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="text-center">
                  <span className="font-black text-lg leading-tight uppercase tracking-tight block mb-2">{item.title}</span>
                  <p className="text-[10px] font-bold text-[#800000]/40 uppercase tracking-widest leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-8 py-32 bg-[#800000] text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 relative z-10">
          <div>
            <h2 className="text-5xl md:text-7xl font-black mb-12 tracking-tighter uppercase italic">Get In Touch</h2>
            <div className="space-y-10">
              {[
                { label: 'Administration', val: '+255 785 276 159' },
                { label: 'Email Us', val: 'info@dumila.ac.tz' },
                { label: 'Location', val: 'Dumila, Morogoro, Tanzania' }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-8 group">
                  <div className="w-16 h-16 bg-white text-[#800000] rounded-2xl flex items-center justify-center border-4 border-[#1a1a1a] shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] group-hover:rotate-12 transition-transform">
                    <SchoolLogo className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black tracking-[0.3em] text-white/50 mb-1 uppercase">{item.label}</p>
                    <p className="text-xl md:text-2xl font-black tracking-tight text-white">{item.val}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white p-10 md:p-16 rounded-[3rem] border-4 border-[#800000] shadow-[20px_20px_0px_0px_rgba(218,165,32,1)]">
            <h3 className="text-3xl font-black mb-10 text-[#800000] tracking-tighter uppercase italic">Quick Inquiry</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <input type="text" placeholder="Your Full Name" className="w-full px-8 py-5 bg-[#fdfcf0] text-[#800000] border-4 border-[#800000] rounded-2xl focus:outline-none focus:ring-4 focus:ring-[#daa520]/10 transition-all placeholder:text-[#800000]/30 font-bold text-lg" />
                <input type="email" placeholder="Email Address" className="w-full px-8 py-5 bg-[#fdfcf0] text-[#800000] border-4 border-[#800000] rounded-2xl focus:outline-none focus:ring-4 focus:ring-[#daa520]/10 transition-all placeholder:text-[#800000]/30 font-bold text-lg" />
              </div>
              <textarea placeholder="How can we help you?" rows={4} className="w-full px-8 py-5 bg-[#fdfcf0] text-[#800000] border-4 border-[#800000] rounded-2xl focus:outline-none focus:ring-4 focus:ring-[#daa520]/10 transition-all placeholder:text-[#800000]/30 font-bold text-lg"></textarea>
              <button className="w-full py-6 bg-[#800000] text-white font-black text-xl rounded-2xl hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] active:translate-x-1 active:translate-y-1 active:shadow-none uppercase tracking-widest">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-8 py-24 bg-white border-t-4 border-[#800000]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-16 mb-20">
            <div className="flex flex-col items-center md:items-start gap-10">
              <span className="text-[10px] font-black tracking-[0.5em] text-[#800000] uppercase">Connect With Us</span>
              <div className="flex flex-wrap justify-center md:justify-start gap-6">
                {[
                  { icon: Instagram, label: 'Instagram' },
                  { icon: Twitter, label: 'X (Twitter)' },
                  { icon: Facebook, label: 'Facebook' },
                  { icon: MessageCircle, label: 'WhatsApp' }
                ].map((social, i) => (
                  <a 
                    key={i} 
                    href="#" 
                    className="w-16 h-16 bg-white text-[#800000] border-4 border-[#800000] flex items-center justify-center hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-[6px_6px_0px_0px_rgba(218,165,32,1)] active:translate-x-1 active:translate-y-1 active:shadow-none group rounded-2xl"
                    aria-label={social.label}
                  >
                    <social.icon className="w-8 h-8 group-hover:scale-110 transition-transform" />
                  </a>
                ))}
              </div>
            </div>
            <div className="flex flex-col items-center md:items-end gap-4">
              <div className="flex items-center gap-4">
                <SchoolLogo className="w-12 h-12" />
                <p className="text-3xl font-black tracking-tighter uppercase italic text-[#800000]">Dumila</p>
              </div>
              <p className="text-sm font-black tracking-[0.2em] text-[#daa520]/40 uppercase">Morogoro, Tanzania</p>
            </div>
          </div>
          <div className="pt-16 border-t-2 border-[#800000]/5 text-center md:text-left">
            <p className="text-[10px] font-black tracking-[0.3em] text-[#800000]/40 uppercase">
              &copy; 2026 Dumila Secondary School. All rights reserved. | Built for Excellence
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

