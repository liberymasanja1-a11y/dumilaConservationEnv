import React, { useEffect, useState } from 'react';
import { ClipboardCheck, Plus, Trash2, Search, Filter, GraduationCap, ArrowUpRight, CheckCircle2, Send, FileText, Loader2 } from 'lucide-react';
import { collection, onSnapshot, addDoc, deleteDoc, doc, query, where, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { calculateGrade, calculateDivision, STANDARD_SUBJECTS } from '../lib/necta';
import { apiFetch } from '../lib/api';
import { logActivity } from '../lib/audit';

export default function ResultsView() {
  const { userData, user } = useAuth();
  const [results, setResults] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newResult, setNewResult] = useState({ 
    studentId: '', 
    subject: 'Mathematics', 
    caScore: '', 
    examScore: '', 
    term: 'Term 1', 
    year: '2026',
    form: 'Form 1'
  });
  const [loading, setLoading] = useState(false);
  const [sendingSms, setSendingSms] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const isStaff = userData?.role === 'admin' || userData?.role === 'teacher';

  useEffect(() => {
    if (!user) return;

    let q = query(collection(db, 'results'), orderBy('year', 'desc'), orderBy('term', 'desc'));
    if (!isStaff && userData?.role === 'student') {
      q = query(collection(db, 'results'), where('studentId', '==', user.uid));
    }

    const unsubResults = onSnapshot(q, (snapshot) => {
      setResults(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    let unsubUsers = () => {};
    if (isStaff) {
      unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
        setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).filter((u: any) => u.role === 'student'));
      });
    }

    return () => {
      unsubResults();
      unsubUsers();
    };
  }, [user, isStaff, userData?.role]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const ca = parseFloat(newResult.caScore);
      const exam = parseFloat(newResult.examScore);
      const total = ca + exam;
      const grade = calculateGrade(total);
      const student = users.find(u => u.id === newResult.studentId);

      const resultData = {
        ...newResult,
        studentName: student?.displayName || 'Unknown',
        caScore: ca,
        examScore: exam,
        totalScore: total,
        grade,
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'results'), resultData);
      await logActivity('ADD_RESULT', `Added ${newResult.subject} result for ${resultData.studentName}`);
      
      setIsAdding(false);
      setNewResult({ 
        studentId: '', 
        subject: 'Mathematics', 
        caScore: '', 
        examScore: '', 
        term: 'Term 1', 
        year: '2026',
        form: 'Form 1'
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this result?')) return;
    try {
      await deleteDoc(doc(db, 'results', id));
      await logActivity('DELETE_RESULT', `Deleted result record ${id}`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendSms = async (result: any) => {
    setSendingSms(result.id);
    try {
      const student = users.find(u => u.id === result.studentId);
      const message = `Dumila Sec: ${student?.displayName}, ${result.subject} Result - CA: ${result.caScore}, Exam: ${result.examScore}, Total: ${result.totalScore}, Grade: ${result.grade}. Term: ${result.term} ${result.year}`;
      
      await apiFetch('/api/sms/send', {
        method: 'POST',
        body: {
          recipient: student?.phone || 'Parent Phone', // Assuming phone exists or placeholder
          message,
          type: 'Result'
        } as any
      });
      alert('SMS Notification sent to parent!');
    } catch (err) {
      console.error(err);
      alert('Failed to send SMS.');
    } finally {
      setSendingSms(null);
    }
  };

  const filteredResults = results.filter(r => {
    const searchStr = `${r.subject} ${r.studentName} ${r.term} ${r.form}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  // Group results by student for Division calculation
  const studentResults = results.reduce((acc: any, curr: any) => {
    if (!acc[curr.studentId]) acc[curr.studentId] = [];
    acc[curr.studentId].push(curr);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">NECTA Academic Portal</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Form 1 - Form 4 O-Level Standards</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-[#800000] text-white font-black rounded-2xl flex items-center gap-2 hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-xl shadow-[#800000]/20 text-[10px] uppercase tracking-widest active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Record Performance</span>
          </button>
        )}
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)]"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-[#fdfcf0] rounded-xl flex items-center justify-center border-2 border-[#800000]">
                <GraduationCap className="w-5 h-5 text-[#800000]" />
              </div>
              <h2 className="text-xl font-black uppercase tracking-tight text-[#800000]">New NECTA Assessment Entry</h2>
            </div>
            <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Student</label>
                <select
                  value={newResult.studentId}
                  onChange={(e) => setNewResult({ ...newResult, studentId: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                >
                  <option value="">Select Student</option>
                  {users.map(u => (
                    <option key={u.id} value={u.id}>{u.displayName} ({u.studentId || u.username})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Subject</label>
                <select
                  value={newResult.subject}
                  onChange={(e) => setNewResult({ ...newResult, subject: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                >
                  {STANDARD_SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">CA (Max 30)</label>
                <input
                  type="number"
                  min="0"
                  max="30"
                  step="0.1"
                  value={newResult.caScore}
                  onChange={(e) => setNewResult({ ...newResult, caScore: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="e.g. 25"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Exam (Max 70)</label>
                <input
                  type="number"
                  min="0"
                  max="70"
                  step="0.1"
                  value={newResult.examScore}
                  onChange={(e) => setNewResult({ ...newResult, examScore: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="e.g. 55"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Form</label>
                <select
                  value={newResult.form}
                  onChange={(e) => setNewResult({ ...newResult, form: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                >
                  <option value="Form 1">Form 1</option>
                  <option value="Form 2">Form 2</option>
                  <option value="Form 3">Form 3</option>
                  <option value="Form 4">Form 4</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Term</label>
                <select
                  value={newResult.term}
                  onChange={(e) => setNewResult({ ...newResult, term: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                >
                  <option value="Term 1">Term 1</option>
                  <option value="Term 2">Term 2</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Year</label>
                <input
                  type="text"
                  value={newResult.year}
                  onChange={(e) => setNewResult({ ...newResult, year: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                />
              </div>
              <div className="md:col-span-4 flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-6 py-3 font-black text-[10px] uppercase tracking-widest text-[#800000]/40 hover:text-[#800000] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-10 py-4 bg-[#800000] text-white font-black rounded-2xl hover:bg-[#daa520] hover:text-[#800000] transition-all disabled:opacity-50 text-[10px] uppercase tracking-widest shadow-xl shadow-black/10"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirm Entry'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
          <input
            type="text"
            placeholder="Search by subject, student, or form..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
          />
        </div>
        <button className="px-6 py-4 bg-white border-2 border-[#800000] rounded-2xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
          <Filter className="w-4 h-4" />
          <span>Filter</span>
        </button>
      </div>

      <div className="bg-white rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-[#fdfcf0] border-b-2 border-[#800000]">
                {isStaff && <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Student</th>}
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Subject / Form</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">CA (30)</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Exam (70)</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Total</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Grade</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#800000]/5">
              {filteredResults.length === 0 ? (
                <tr>
                  <td colSpan={isStaff ? 7 : 6} className="px-8 py-20 text-center">
                    <div className="w-16 h-16 bg-[#fdfcf0] rounded-2xl flex items-center justify-center mx-auto mb-4 border-2 border-dashed border-[#800000]/10">
                      <ClipboardCheck className="w-8 h-8 text-[#800000]/10" />
                    </div>
                    <p className="text-sm font-black text-[#800000]/40 uppercase tracking-widest">No academic records found</p>
                  </td>
                </tr>
              ) : (
                filteredResults.map((result) => (
                  <tr key={result.id} className="hover:bg-[#fdfcf0]/50 transition-colors group">
                    {isStaff && (
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-[#800000] rounded-lg flex items-center justify-center text-white text-[10px] font-black">
                            {result.studentName?.[0] || '?'}
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm font-black text-[#800000]">{result.studentName}</span>
                            <span className="text-[9px] font-bold text-[#800000]/30 uppercase tracking-widest">
                              {users.find(u => u.id === result.studentId)?.studentId || 'No ID'}
                            </span>
                          </div>
                        </div>
                      </td>
                    )}
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-[#800000]">{result.subject}</span>
                        <span className="text-[9px] font-bold text-[#daa520] uppercase tracking-widest">{result.form} • {result.term}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-sm font-bold text-[#800000]/60">{result.caScore}</span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-sm font-bold text-[#800000]/60">{result.examScore}</span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="px-3 py-1 bg-[#800000]/5 text-[#800000] rounded-xl text-[10px] font-black uppercase tracking-widest border border-[#800000]/10">
                        {result.totalScore}%
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`
                        w-9 h-9 flex items-center justify-center rounded-xl font-black text-white text-xs shadow-lg
                        ${result.grade === 'A' ? 'bg-green-500 shadow-green-500/20' : 
                          result.grade === 'B' ? 'bg-blue-500 shadow-blue-500/20' : 
                          result.grade === 'C' ? 'bg-yellow-500 shadow-yellow-500/20' : 
                          result.grade === 'D' ? 'bg-orange-500 shadow-orange-500/20' : 'bg-red-500 shadow-red-500/20'}
                      `}>
                        {result.grade}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {isStaff && (
                          <button
                            onClick={() => handleSendSms(result)}
                            disabled={sendingSms === result.id}
                            className="p-2 text-[#DAA520] hover:text-[#800000] hover:bg-[#DAA520]/10 rounded-xl transition-all active:scale-90"
                            title="Send SMS to Parent"
                          >
                            {sendingSms === result.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                          </button>
                        )}
                        {isStaff && (
                          <button
                            onClick={() => handleDelete(result.id)}
                            className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-90"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Summary / Division Calculation */}
      {isStaff && Object.keys(studentResults).length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-[#800000] p-8 rounded-3xl border-2 border-[#800000] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] text-white">
            <h3 className="text-xl font-black mb-6 flex items-center gap-3 uppercase tracking-tight italic">
              <FileText className="w-5 h-5 text-[#DAA520]" />
              NECTA Division Summaries
            </h3>
            <div className="space-y-4">
              {Object.entries(studentResults).map(([studentId, res]: [string, any]) => {
                const division = calculateDivision(res);
                const student = users.find(u => u.id === studentId);
                if (!student) return null;
                return (
                  <div key={studentId} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/10 group hover:border-[#DAA520] transition-colors">
                    <div className="flex flex-col">
                      <span className="text-sm font-black uppercase tracking-tight">{student.displayName}</span>
                      <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest">{res.length} Subjects Recorded</span>
                    </div>
                    <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest ${
                      division.includes('I') && !division.includes('IV') ? 'bg-green-500 text-white' :
                      division.includes('IV') || division.includes('0') ? 'bg-red-500 text-white' : 'bg-[#DAA520] text-[#800000]'
                    }`}>
                      {division}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
