import React from 'react';
import { HelpCircle, Book, Video, MessageCircle, FileText, ChevronRight } from 'lucide-react';

export default function TrainingView() {
  const guides = [
    {
      title: 'Getting Started for Teachers',
      description: 'Learn how to manage classes, record results, and post announcements.',
      icon: Book,
      color: 'bg-blue-500'
    },
    {
      title: 'Financial Management Guide',
      description: 'Instructions for recording capitation funds and operational expenses.',
      icon: FileText,
      color: 'bg-green-500'
    },
    {
      title: 'Parent & Student Portal',
      description: 'How to view results, check timetables, and receive SMS notifications.',
      icon: Video,
      color: 'bg-purple-500'
    },
    {
      title: 'Troubleshooting & Support',
      description: 'Common issues and how to resolve them or contact system admin.',
      icon: MessageCircle,
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight uppercase italic flex items-center gap-4">
          <HelpCircle className="w-8 h-8 text-[#800000]" />
          Training & Support
        </h1>
        <p className="text-sm font-bold text-[#1a1a1a]/40 uppercase tracking-widest mt-1">User manuals and system documentation</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {guides.map((guide, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl border-2 border-[#1a1a1a] shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] hover:shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] transition-all group cursor-pointer">
            <div className="flex items-start justify-between mb-6">
              <div className={`p-4 rounded-2xl ${guide.color} text-white shadow-lg`}>
                <guide.icon className="w-6 h-6" />
              </div>
              <ChevronRight className="w-6 h-6 text-[#1a1a1a]/20 group-hover:text-[#1a1a1a] transition-colors" />
            </div>
            <h3 className="text-xl font-black text-[#1a1a1a] uppercase tracking-tight mb-2 italic">{guide.title}</h3>
            <p className="text-sm font-bold text-[#1a1a1a]/60 leading-relaxed">{guide.description}</p>
            <div className="mt-8 pt-6 border-t-2 border-[#1a1a1a]/5 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-[#800000]">Read Manual</span>
              <span className="text-[9px] font-bold text-[#1a1a1a]/30 uppercase tracking-widest">15 min read</span>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#1a1a1a] p-10 rounded-3xl border-2 border-[#1a1a1a] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)] text-white">
        <div className="max-w-2xl">
          <h2 className="text-2xl font-black uppercase tracking-tight mb-4 italic">Need Immediate Assistance?</h2>
          <p className="text-sm font-bold text-white/60 uppercase tracking-widest leading-relaxed mb-8">
            If you encounter any technical issues or have questions not covered in the manuals, please contact the school ICT department.
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="px-6 py-4 bg-white/10 rounded-2xl border border-white/10">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-1">Email Support</p>
              <p className="text-sm font-bold">ict@dumila.sc.tz</p>
            </div>
            <div className="px-6 py-4 bg-white/10 rounded-2xl border border-white/10">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-1">Phone Support</p>
              <p className="text-sm font-bold">+255 700 000 000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
