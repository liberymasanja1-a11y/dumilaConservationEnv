import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Users, BookOpen, Bell, TrendingUp, Calendar, Shield, ArrowUpRight, UserCheck, Database, HelpCircle, History, Loader2, Activity } from 'lucide-react';
import { collection, onSnapshot, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import { logActivity } from '../lib/audit';

import { useNavigate } from 'react-router-dom';

export default function AdminDashboard() {
  const { userData } = useAuth();
  const navigate = useNavigate();
  const [counts, setCounts] = React.useState({ students: 0, teachers: 0, announcements: 0 });
  const [recentLogs, setRecentLogs] = React.useState<any[]>([]);
  const [backingUp, setBackingUp] = React.useState(false);

  React.useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const users = snapshot.docs.map(doc => doc.data());
      setCounts(prev => ({
        ...prev,
        students: users.filter((u: any) => u.role === 'student').length,
        teachers: users.filter((u: any) => u.role === 'teacher').length
      }));
    });

    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      setCounts(prev => ({
        ...prev,
        announcements: snapshot.size
      }));
    });

    const qLogs = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(5));
    const unsubLogs = onSnapshot(qLogs, (snapshot) => {
      setRecentLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubUsers();
      unsubAnnouncements();
      unsubLogs();
    };
  }, []);

  const handleBackup = async () => {
    setBackingUp(true);
    try {
      const collections = ['users', 'results', 'finances', 'announcements', 'timetable'];
      const backupData: any = {};
      
      for (const colName of collections) {
        const snapshot = await getDocs(collection(db, colName));
        backupData[colName] = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      }

      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `dumila_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      
      await logActivity('SYSTEM_BACKUP', 'Manual system data backup performed');
      alert('Backup completed successfully!');
    } catch (err) {
      console.error(err);
      alert('Backup failed.');
    } finally {
      setBackingUp(false);
    }
  };

  const stats = [
    { label: 'Students', value: counts.students, icon: UserCheck, color: 'bg-green-500', trend: '+12%' },
    { label: 'Teachers', value: counts.teachers, icon: Shield, color: 'bg-purple-500', trend: '+2' },
    { label: 'Classes', value: '12', icon: BookOpen, color: 'bg-blue-500', trend: 'Active' },
    { label: 'Notices', value: counts.announcements, icon: Bell, color: 'bg-orange-500', trend: 'Live' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">Admin Overview</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">System Status & Statistics</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-white rounded-2xl border-2 border-[#800000] shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
          <Calendar className="w-4 h-4 text-[#800000]" />
          <span className="text-[10px] font-black text-[#800000] uppercase tracking-widest">
            {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </span>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] hover:shadow-[12px_12px_0px_0px_rgba(128,0,0,1)] transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`p-3 rounded-2xl ${stat.color} text-white shadow-lg`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <div className="flex items-center gap-1 text-[10px] font-black text-green-600 bg-green-50 px-2 py-1 rounded-full uppercase tracking-widest">
                <TrendingUp className="w-3 h-3" />
                {stat.trend}
              </div>
            </div>
            <h3 className="text-[10px] font-black text-[#800000]/40 uppercase tracking-[0.2em] mb-1">{stat.label}</h3>
            <p className="text-4xl font-black text-[#800000] tracking-tighter">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)]">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-[#800000] uppercase tracking-tight italic">Audit Trail Activity</h2>
              <button className="text-[10px] font-black text-[#800000] uppercase tracking-widest hover:underline flex items-center gap-2">
                <History className="w-3 h-3" />
                Full Logs
              </button>
            </div>
            <div className="space-y-4">
              {recentLogs.length === 0 ? (
                <p className="text-center py-10 text-[10px] font-black uppercase tracking-widest text-[#800000]/20">No recent activity</p>
              ) : (
                recentLogs.map((log, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#fdfcf0] transition-colors group border border-transparent hover:border-[#800000]/5">
                    <div className="w-12 h-12 bg-[#fdfcf0] rounded-xl flex items-center justify-center border border-[#800000]/5 group-hover:bg-[#800000] group-hover:text-white transition-colors">
                      <Activity className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-[#800000]">{log.action}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] font-bold text-[#daa520] uppercase tracking-wider">{log.details}</span>
                        <span className="w-0.5 h-0.5 bg-[#800000]/10 rounded-full" />
                        <span className="text-[10px] font-medium text-[#800000]/30">{new Date(log.timestamp).toLocaleTimeString()}</span>
                      </div>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-[#800000]/20 group-hover:text-[#800000] transition-colors" />
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-[#800000] p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] text-white relative overflow-hidden group">
            <div className="relative z-10">
              <h2 className="text-xl font-black uppercase tracking-tight mb-2 italic">System Maintenance</h2>
              <p className="text-xs font-bold text-white/60 uppercase tracking-widest mb-6">Critical administrative tools</p>
              <div className="space-y-3">
                <button 
                  onClick={handleBackup}
                  disabled={backingUp}
                  className="w-full py-4 bg-white text-[#800000] rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-[1.02] transition-transform active:scale-95 shadow-xl shadow-black/20 flex items-center justify-center gap-3"
                >
                  {backingUp ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
                  Perform Data Backup
                </button>
                <button 
                  onClick={() => navigate('/dashboard/training')}
                  className="w-full py-4 bg-white/10 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-white/20 transition-all border border-white/10 flex items-center justify-center gap-3"
                >
                  <HelpCircle className="w-4 h-4" />
                  Training & Support
                </button>
              </div>
            </div>
            <Shield className="absolute -bottom-8 -right-8 w-32 h-32 text-white/5 rotate-12 group-hover:scale-110 transition-transform duration-700" />
          </div>

          <div className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)]">
            <h3 className="text-lg font-black text-[#800000] uppercase tracking-tight mb-6 italic">School Calendar</h3>
            <div className="space-y-6">
              {[
                { date: '15', month: 'APR', title: 'Mid-Term Exams', time: '08:00 AM' },
                { date: '22', month: 'APR', title: 'Sports Day', time: '10:00 AM' }
              ].map((event, i) => (
                <div key={i} className="flex gap-4 items-center group cursor-pointer">
                  <div className="w-14 h-14 bg-[#800000] rounded-2xl flex flex-col items-center justify-center text-white flex-shrink-0 shadow-xl shadow-black/10 group-hover:scale-110 transition-transform">
                    <span className="text-xl font-black leading-none">{event.date}</span>
                    <span className="text-[9px] font-black tracking-widest mt-1 opacity-50">{event.month}</span>
                  </div>
                  <div>
                    <p className="text-sm font-black text-[#800000] group-hover:text-[#daa520] transition-colors">{event.title}</p>
                    <p className="text-[10px] font-bold text-[#800000]/30 mt-1 uppercase tracking-widest">{event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

