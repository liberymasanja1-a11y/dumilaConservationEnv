import React, { useEffect, useState } from 'react';
import { Wallet, Plus, Trash2, Search, Filter, TrendingUp, TrendingDown, DollarSign, Loader2, PieChart } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { apiFetch } from '../lib/api';

export default function FinancesView() {
  const { userData } = useAuth();
  const [records, setRecords] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newRecord, setNewRecord] = useState({ 
    type: 'Capitation Fund', 
    category: 'Stationery', 
    amount: '', 
    description: '' 
  });
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const isAdmin = userData?.role === 'admin';

  useEffect(() => {
    const q = query(collection(db, 'finances'), orderBy('date', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setRecords(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await apiFetch('/api/finances', {
        method: 'POST',
        body: {
          ...newRecord,
          amount: parseFloat(newRecord.amount)
        } as any
      });
      setIsAdding(false);
      setNewRecord({ type: 'Capitation Fund', category: 'Stationery', amount: '', description: '' });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const totalCapitation = records.filter(r => r.type === 'Capitation Fund').reduce((sum, r) => sum + r.amount, 0);
  const totalVoluntary = records.filter(r => r.type === 'Voluntary Contribution').reduce((sum, r) => sum + r.amount, 0);
  const totalOperational = records.filter(r => r.type === 'Operational Fund').reduce((sum, r) => sum + r.amount, 0);

  const filteredRecords = records.filter(r => {
    const searchStr = `${r.type} ${r.category} ${r.description}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#800000] tracking-tight uppercase italic">Financial Management</h1>
          <p className="text-sm font-bold text-[#800000]/40 uppercase tracking-widest mt-1">Free Education Policy Compliance</p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-[#800000] text-white font-black rounded-2xl flex items-center gap-2 hover:bg-[#daa520] hover:text-[#800000] transition-all shadow-xl shadow-black/10 text-[10px] uppercase tracking-widest active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Record Transaction</span>
          </button>
        )}
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border-2 border-[#800000] shadow-[6px_6px_0px_0px_rgba(218,165,32,1)]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center border-2 border-blue-100">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Capitation Funds</span>
          </div>
          <p className="text-2xl font-black text-[#800000]">{totalCapitation.toLocaleString()} TZS</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border-2 border-[#800000] shadow-[6px_6px_0px_0px_rgba(218,165,32,1)]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center border-2 border-green-100">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Voluntary Contrib.</span>
          </div>
          <p className="text-2xl font-black text-[#800000]">{totalVoluntary.toLocaleString()} TZS</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border-2 border-[#800000] shadow-[6px_6px_0px_0px_rgba(218,165,32,1)]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center border-2 border-purple-100">
              <PieChart className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Operational Funds</span>
          </div>
          <p className="text-2xl font-black text-[#800000]">{totalOperational.toLocaleString()} TZS</p>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white p-8 rounded-3xl border-2 border-[#800000] shadow-[12px_12px_0px_0px_rgba(218,165,32,1)]"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-[#fdfcf0] rounded-xl flex items-center justify-center border-2 border-[#800000]">
                <Wallet className="w-5 h-5 text-[#800000]" />
              </div>
              <h2 className="text-xl font-black uppercase tracking-tight text-[#800000]">Record New Transaction</h2>
            </div>
            <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Fund Type</label>
                <select
                  value={newRecord.type}
                  onChange={(e) => setNewRecord({ ...newRecord, type: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  required
                >
                  <option value="Capitation Fund">Capitation Fund</option>
                  <option value="Voluntary Contribution">Voluntary Contribution</option>
                  <option value="Operational Fund">Operational Fund</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Category</label>
                <input
                  type="text"
                  value={newRecord.category}
                  onChange={(e) => setNewRecord({ ...newRecord, category: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="e.g. Stationery, Meals, Repairs"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Amount (TZS)</label>
                <input
                  type="number"
                  value={newRecord.amount}
                  onChange={(e) => setNewRecord({ ...newRecord, amount: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="500000"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Description</label>
                <input
                  type="text"
                  value={newRecord.description}
                  onChange={(e) => setNewRecord({ ...newRecord, description: e.target.value })}
                  className="w-full px-4 py-4 bg-[#fdfcf0] border-2 border-[#800000] rounded-2xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
                  placeholder="Optional details..."
                />
              </div>
              <div className="md:col-span-2 lg:col-span-4 flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-6 py-3 font-black text-[10px] uppercase tracking-widest text-[#800000]/40 hover:text-[#800000] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-10 py-4 bg-[#800000] text-white font-black rounded-2xl hover:bg-[#daa520] hover:text-[#800000] transition-all disabled:opacity-50 text-[10px] uppercase tracking-widest shadow-xl shadow-black/10"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Record Transaction'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-3xl border-2 border-[#800000] shadow-[8px_8px_0px_0px_rgba(218,165,32,1)] overflow-hidden">
        <div className="p-6 border-b-2 border-[#800000] bg-[#fdfcf0] flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#800000]/20" />
            <input
              type="text"
              placeholder="Search financial records..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border-2 border-[#800000] rounded-xl focus:ring-4 focus:ring-[#daa520]/10 outline-none font-bold text-[#800000] text-sm"
            />
          </div>
          <button className="px-6 py-3 bg-white border-2 border-[#800000] rounded-xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest hover:bg-[#fdfcf0] text-[#800000] transition-all shadow-[4px_4px_0px_0px_rgba(218,165,32,1)]">
            <Filter className="w-4 h-4" />
            <span>Filter</span>
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-[#fdfcf0] border-b-2 border-[#800000]">
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Date</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Type</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Category</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Amount</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-[#800000]/40">Recorded By</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#800000]/5">
              {filteredRecords.map((record) => (
                <tr key={record.id} className="hover:bg-[#fdfcf0]/50 transition-colors group">
                  <td className="px-8 py-5 text-xs font-bold text-[#800000]/40">
                    {new Date(record.date).toLocaleDateString()}
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border-2 ${
                      record.type === 'Capitation Fund' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                      record.type === 'Voluntary Contribution' ? 'bg-green-50 text-green-600 border-green-100' :
                      'bg-purple-50 text-purple-600 border-purple-100'
                    }`}>
                      {record.type}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex flex-col">
                      <span className="text-sm font-black text-[#800000]">{record.category}</span>
                      <span className="text-[9px] font-bold text-[#800000]/30 uppercase tracking-widest">{record.description}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="text-sm font-black text-[#800000]">{record.amount.toLocaleString()} TZS</span>
                  </td>
                  <td className="px-8 py-5 text-xs font-bold text-[#800000]/40">
                    {record.recordedBy}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
