/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import DashboardLayout from './components/DashboardLayout';
import AdminDashboard from './components/AdminDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import ParentDashboard from './components/ParentDashboard';
import StudentDashboard from './components/StudentDashboard';
import AdminUserManagement from './components/AdminUserManagement';
import StudentsView from './components/StudentsView';
import ClassesView from './components/ClassesView';
import ResultsView from './components/ResultsView';
import TimetableView from './components/TimetableView';
import AnnouncementsView from './components/AnnouncementsView';
import FinancesView from './components/FinancesView';
import AuditTrailView from './components/AuditTrailView';
import SmsLogsView from './components/SmsLogsView';
import TrainingView from './components/TrainingView';
import LandingPage from './components/LandingPage';

function PrivateRoute({ children, requiredRole }: { children: React.ReactNode, requiredRole?: string }) {
  const { user, userData, loading } = useAuth();

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (requiredRole && userData?.role !== requiredRole) return <Navigate to="/" />;

  return <>{children}</>;
}

function RoleBasedDashboard() {
  const { userData } = useAuth();

  switch (userData?.role) {
    case 'admin': return <AdminDashboard />;
    case 'teacher': return <TeacherDashboard />;
    case 'parent': return <ParentDashboard />;
    case 'student': return <StudentDashboard />;
    default: return <div className="p-8 text-center">User role not found. Please contact administration.</div>;
  }
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={
            <PrivateRoute>
              <DashboardLayout>
                <RoleBasedDashboard />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/users" element={
            <PrivateRoute requiredRole="admin">
              <DashboardLayout>
                <AdminUserManagement />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/students" element={
            <PrivateRoute>
              <DashboardLayout>
                <StudentsView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/classes" element={
            <PrivateRoute>
              <DashboardLayout>
                <ClassesView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/results" element={
            <PrivateRoute>
              <DashboardLayout>
                <ResultsView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/finances" element={
            <PrivateRoute requiredRole="admin">
              <DashboardLayout>
                <FinancesView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/audit" element={
            <PrivateRoute requiredRole="admin">
              <DashboardLayout>
                <AuditTrailView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/sms" element={
            <PrivateRoute>
              <DashboardLayout>
                <SmsLogsView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/training" element={
            <PrivateRoute>
              <DashboardLayout>
                <TrainingView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/timetable" element={
            <PrivateRoute>
              <DashboardLayout>
                <TimetableView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="/dashboard/announcements" element={
            <PrivateRoute>
              <DashboardLayout>
                <AnnouncementsView />
              </DashboardLayout>
            </PrivateRoute>
          } />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}


