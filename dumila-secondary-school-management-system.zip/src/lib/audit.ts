import { db, auth } from './firebase';
import { collection, addDoc } from 'firebase/firestore';

export const logActivity = async (action: string, details: string) => {
  try {
    const user = auth.currentUser;
    if (!user) return;

    await addDoc(collection(db, 'auditLogs'), {
      userId: user.uid,
      action,
      details,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
};
