export type Grade = 'A' | 'B' | 'C' | 'D' | 'F';

export const calculateGrade = (score: number): Grade => {
  if (score >= 75) return 'A';
  if (score >= 65) return 'B';
  if (score >= 45) return 'C';
  if (score >= 30) return 'D';
  return 'F';
};

export const getGradePoints = (grade: Grade): number => {
  switch (grade) {
    case 'A': return 1;
    case 'B': return 2;
    case 'C': return 3;
    case 'D': return 4;
    case 'F': return 5;
    default: return 5;
  }
};

export const calculateDivision = (results: { subject: string; grade: Grade }[]): string => {
  if (results.length < 7) return 'N/A (Min 7 subjects required)';

  // Sort by points (ascending, so A=1 is best)
  const points = results
    .map(r => getGradePoints(r.grade))
    .sort((a, b) => a - b)
    .slice(0, 7);

  const totalPoints = points.reduce((sum, p) => sum + p, 0);

  if (totalPoints <= 17) return 'Division I';
  if (totalPoints <= 21) return 'Division II';
  if (totalPoints <= 25) return 'Division III';
  if (totalPoints <= 33) return 'Division IV';
  return 'Division 0';
};

export const STANDARD_SUBJECTS = [
  'Mathematics',
  'English',
  'Kiswahili',
  'Biology',
  'Chemistry',
  'Physics',
  'Geography',
  'History',
  'Civics'
];
