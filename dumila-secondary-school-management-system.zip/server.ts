import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import admin from "firebase-admin";

// Initialize Firebase Admin
// In AIS Build, the environment should have the necessary credentials
// or we can use the default initialization which works in Cloud Run.
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();
const auth = admin.auth();

const app = express();
const PORT = 3000;

app.use(express.json());

// Auth Middleware using Firebase Admin
const authenticate = async (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    const decodedToken = await auth.verifyIdToken(token);
    // Get user data from Firestore
    const userDoc = await db.collection('users').doc(decodedToken.uid).get();
    if (!userDoc.exists) {
      return res.status(401).json({ error: "User profile not found" });
    }
    req.user = { ...decodedToken, ...userDoc.data() };
    next();
  } catch (err) {
    console.error("Auth Error:", err);
    res.status(401).json({ error: "Invalid token" });
  }
};

// API Routes
app.post("/api/users", authenticate, async (req: any, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  
  const { username, password, role, displayName, email: providedEmail, form } = req.body;
  const email = providedEmail || `${username.toLowerCase()}@dumila.ac.tz`;

  try {
    let studentId = null;
    if (role === 'student') {
      // Generate unique student ID: DUM/2026/XXXX
      const counterRef = db.collection('counters').doc('studentId');
      await db.runTransaction(async (transaction) => {
        const counterDoc = await transaction.get(counterRef);
        let nextId = 1;
        if (counterDoc.exists) {
          nextId = counterDoc.data()?.count + 1;
        }
        transaction.set(counterRef, { count: nextId });
        studentId = `DUM/2026/${nextId.toString().padStart(4, '0')}`;
      });
    }

    // Create user in Firebase Auth
    const userRecord = await auth.createUser({
      email,
      password: password || "student@123",
      displayName,
    });

    // Create user profile in Firestore
    const userData: any = {
      uid: userRecord.uid,
      username: username.toLowerCase(),
      role,
      displayName,
      email,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };

    if (studentId) userData.studentId = studentId;
    if (form) userData.form = form;

    await db.collection('users').doc(userRecord.uid).set(userData);

    // Log activity
    await db.collection('auditLogs').add({
      userId: req.user.uid,
      action: 'CREATE_USER',
      details: `Created ${role} user: ${username} (${studentId || 'N/A'})`,
      timestamp: new Date().toISOString()
    });

    res.json(userData);
  } catch (error: any) {
    console.error("Error creating user:", error);
    res.status(400).json({ error: error.message });
  }
});

app.post("/api/users/bulk", authenticate, async (req: any, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  const users = req.body;
  
  if (!Array.isArray(users)) {
    return res.status(400).json({ error: "Invalid data format. Expected an array." });
  }

  const results = {
    created: 0,
    skipped: 0,
    errors: [] as string[]
  };

  for (const userData of users) {
    const { username, password, role, displayName, email: providedEmail, form } = userData;
    const email = providedEmail || `${username.toLowerCase()}@dumila.ac.tz`;
    
    if (!username || !role || !displayName) {
      results.errors.push(`Missing required fields for: ${username || 'unknown'}`);
      results.skipped++;
      continue;
    }

    try {
      // Check if user exists in Firestore first (by username)
      const existingUser = await db.collection('users').where('username', '==', username.toLowerCase()).get();
      if (!existingUser.empty) {
        results.skipped++;
        continue;
      }

      let studentId = null;
      if (role === 'student') {
        const counterRef = db.collection('counters').doc('studentId');
        await db.runTransaction(async (transaction) => {
          const counterDoc = await transaction.get(counterRef);
          let nextId = 1;
          if (counterDoc.exists) {
            nextId = counterDoc.data()?.count + 1;
          }
          transaction.set(counterRef, { count: nextId });
          studentId = `DUM/2026/${nextId.toString().padStart(4, '0')}`;
        });
      }

      const userRecord = await auth.createUser({
        email,
        password: password || "student@123",
        displayName,
      });

      const profile: any = {
        uid: userRecord.uid,
        username: username.toLowerCase(),
        role,
        displayName,
        email,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };

      if (studentId) profile.studentId = studentId;
      if (form) profile.form = form;

      await db.collection('users').doc(userRecord.uid).set(profile);
      results.created++;
    } catch (error: any) {
      results.errors.push(`Error for ${username}: ${error.message}`);
      results.skipped++;
    }
  }

  // Log activity
  await db.collection('auditLogs').add({
    userId: req.user.uid,
    action: 'BULK_CREATE_USERS',
    details: `Bulk created ${results.created} users`,
    timestamp: new Date().toISOString()
  });

  res.json(results);
});

app.delete("/api/users/:id", authenticate, async (req: any, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  try {
    const userDoc = await db.collection('users').doc(req.params.id).get();
    const userData = userDoc.data();

    // Delete from Auth
    await auth.deleteUser(req.params.id);
    // Delete from Firestore
    await db.collection('users').doc(req.params.id).delete();

    // Log activity
    await db.collection('auditLogs').add({
      userId: req.user.uid,
      action: 'DELETE_USER',
      details: `Deleted user: ${userData?.username} (${userData?.role})`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Finance Endpoints
app.post("/api/finances", authenticate, async (req: any, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  try {
    const record = {
      ...req.body,
      recordedBy: req.user.displayName || req.user.username,
      date: new Date().toISOString()
    };
    const docRef = await db.collection('finances').add(record);
    
    // Log activity
    await db.collection('auditLogs').add({
      userId: req.user.uid,
      action: 'CREATE_FINANCE_RECORD',
      details: `Created ${record.type} record: ${record.amount} TZS`,
      timestamp: new Date().toISOString()
    });

    res.json({ id: docRef.id, ...record });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// SMS Endpoints (Mock)
app.post("/api/sms/send", authenticate, async (req: any, res) => {
  if (req.user.role !== "admin" && req.user.role !== "teacher") return res.status(403).json({ error: "Forbidden" });
  const { recipient, message, type } = req.body;
  
  try {
    // In a real scenario, integrate with Africa's Talking or similar here
    console.log(`Sending SMS to ${recipient}: ${message}`);
    
    const log = {
      recipient,
      message,
      type,
      status: 'Sent', // Mock success
      timestamp: new Date().toISOString()
    };
    
    await db.collection('smsLogs').add(log);
    
    // Log activity
    await db.collection('auditLogs').add({
      userId: req.user.uid,
      action: 'SEND_SMS',
      details: `Sent ${type} SMS to ${recipient}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Migration Logic
const migrateData = async () => {
  const DB_FILE = "database.json";
  if (!fs.existsSync(DB_FILE)) return;

  console.log("Starting data migration to Firestore...");
  try {
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));

    // Migrate Announcements
    if (data.announcements) {
      for (const ann of data.announcements) {
        const { id, ...rest } = ann;
        await db.collection('announcements').doc(id).set(rest);
      }
    }

    // Migrate Timetable
    if (data.timetable) {
      for (const entry of data.timetable) {
        const { id, ...rest } = entry;
        await db.collection('timetable').doc(id).set(rest);
      }
    }

    // Migrate Results
    if (data.results) {
      for (const res of data.results) {
        const { id, ...rest } = res;
        await db.collection('results').doc(id).set(rest);
      }
    }

    // Migrate Users (Note: This only migrates profiles, not Auth accounts)
    if (data.users) {
      for (const user of data.users) {
        const { id, password, ...rest } = user;
        // Check if user exists in Auth, if not we can't easily migrate them with passwords
        // But we can at least store the profile
        await db.collection('users').doc(id).set({
          ...rest,
          uid: id,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
      }
    }

    console.log("Migration complete. Renaming database.json to database.json.bak");
    fs.renameSync(DB_FILE, `${DB_FILE}.bak`);
  } catch (err) {
    console.error("Migration failed:", err);
  }
};

// Vite Setup
async function startServer() {
  await migrateData();
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.post("/api/admin/bootstrap", async (req, res) => {
  const { secret, email, password, username, displayName } = req.body;
  // Simple secret check to prevent unauthorized bootstrapping
  if (secret !== "dumila-bootstrap-2026") {
    return res.status(403).json({ error: "Invalid secret" });
  }

  try {
    const userRecord = await auth.createUser({
      email,
      password,
      displayName,
    });

    const userData = {
      uid: userRecord.uid,
      username: username.toLowerCase(),
      role: "admin",
      displayName,
      email,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await db.collection('users').doc(userRecord.uid).set(userData);
    res.json({ success: true, uid: userRecord.uid });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post("/api/auth/change-password", authenticate, async (req: any, res) => {
  const { newPassword } = req.body;
  try {
    await auth.updateUser(req.user.uid, {
      password: newPassword
    });
    
    await db.collection('auditLogs').add({
      userId: req.user.uid,
      action: 'CHANGE_PASSWORD',
      details: 'User changed their own password',
      timestamp: new Date().toISOString()
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
